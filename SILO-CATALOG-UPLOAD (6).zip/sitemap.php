<?php
header('Content-Type: application/xml; charset=UTF-8');
header('X-Robots-Tag: noindex, follow');
header('Cache-Control: no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');
if (function_exists('apache_setenv')) {
  @apache_setenv('no-gzip', '1');
}
@ini_set('zlib.output_compression', '0');

$index = __DIR__ . '/index.html';
$lastmod = is_file($index) ? gmdate('Y-m-d', filemtime($index)) : gmdate('Y-m-d');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://silosepher.ir/</loc>
    <lastmod><?php echo $lastmod; ?></lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
