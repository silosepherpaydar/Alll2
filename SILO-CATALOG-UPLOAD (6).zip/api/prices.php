<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$root = dirname(__DIR__);

function silo_prices_read_json($path) {
    if (!is_readable($path)) {
        return null;
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function silo_catalog_price_payload(string $root, array $config): array
{
    $rules = silo_prices_read_json($root . '/data/price-rules.json') ?: ['items' => []];
    $items = [];
    foreach ($rules['items'] as $item) {
        if (empty($item['id'])) {
            continue;
        }
        $row = $item;
        $row['market_toman'] = null;
        $row['price'] = null;
        $items[] = $row;
    }
    $now = time();
    return [
        'ok' => true,
        'catalog_only' => true,
        'cached' => true,
        'margin' => null,
        'source' => 'catalog',
        'updated_ts' => $now,
        'updated_at' => date('Y-m-d H:i:s', $now),
        'whatsapp' => (string) ($config['whatsapp'] ?? '989117995099'),
        'items' => $items,
    ];
}

$config = silo_prices_read_json($root . '/config.json') ?: [];
if (!empty($config['catalog_only'])) {
    echo json_encode(silo_catalog_price_payload($root, $config), JSON_UNESCAPED_UNICODE);
    exit;
}

$siloBoot = $root . '/includes/bootstrap.php';
$siloPricing = $root . '/includes/pricing.php';
if (is_file($siloBoot) && is_file($siloPricing)) {
    try {
        require_once $siloBoot;
        require_once $siloPricing;
        silo_boot();
        $published = silo_published_map();
        if ($published) {
            silo_sync_public_prices_json();
            $outFileEarly = dirname(__DIR__) . '/data/prices.json';
            $raw = is_readable($outFileEarly) ? file_get_contents($outFileEarly) : '';
            $payload = json_decode((string) $raw, true);
            if (is_array($payload)) {
                echo json_encode($payload, JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
    } catch (Throwable $e) {
        /* fall through to the original JSON price board */
    }
}

$configFile = $root . '/config.json';
$rulesFile = $root . '/data/price-rules.json';
$marketFile = $root . '/data/market.json';
$outFile = $root . '/data/prices.json';

function read_json($path) {
    if (!is_readable($path)) return null;
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function write_json($path, $data) {
    $tmp = $path . '.tmp';
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (file_put_contents($tmp, $json) === false) return false;
    return rename($tmp, $path);
}

function http_get($url) {
    $raw = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_USERAGENT => 'SiloCatalog/2.0',
        ]);
        $raw = curl_exec($ch);
        curl_close($ch);
    }
    if (!$raw && ini_get('allow_url_fopen')) {
        $raw = @file_get_contents($url);
    }
    return $raw ?: null;
}

function round_price($toman, $step) {
    $step = max(1, (int) $step);
    return (int) (round($toman / $step) * $step);
}

function market_from_sheet($csv) {
    $map = [];
    $csv = preg_replace('/^\xEF\xBB\xBF/', '', $csv);
    $rows = preg_split("/\r\n|\n|\r/", trim($csv));
    if (!$rows) return $map;
    $header = str_getcsv(array_shift($rows));
    $header = array_map('trim', $header);
    foreach ($rows as $line) {
        if (trim($line) === '') continue;
        $cols = str_getcsv($line);
        $row = [];
        foreach ($header as $i => $key) {
            $row[$key] = $cols[$i] ?? '';
        }
        $id = trim((string) ($row['id'] ?? ''));
        if ($id === '') continue;
        $raw = preg_replace('/[^\d]/', '', (string) ($row['market_toman'] ?? ''));
        $map[$id] = $raw === '' ? null : (int) $raw;
    }
    return $map;
}

function market_from_json($data) {
    $map = [];
    foreach (($data['items'] ?? []) as $item) {
        if (empty($item['id'])) continue;
        $val = $item['market_toman'] ?? null;
        $map[$item['id']] = ($val === '' || $val === null) ? null : (int) $val;
    }
    return $map;
}

$config = read_json($configFile) ?: [];
$rules = read_json($rulesFile);
$cached = read_json($outFile);
$now = time();
$ttl = 24 * 60 * 60;

if ($cached && empty($_GET['force']) && !empty($cached['updated_ts']) && ($now - (int) $cached['updated_ts'] < $ttl)) {
    $cached['cached'] = true;
    echo json_encode($cached, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!$rules) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'rules missing'], JSON_UNESCAPED_UNICODE);
    exit;
}

$margin = (float) ($config['margin'] ?? 1.15);
$step = (int) ($config['round_toman'] ?? 5000);
$sheet = trim((string) ($config['google_sheet_csv'] ?? ''));
$source = 'json';
$marketMap = [];

if ($sheet !== '') {
    $csv = http_get($sheet);
    if ($csv) {
        $marketMap = market_from_sheet($csv);
        $source = 'google-sheet';
    }
}
if (!$marketMap) {
    $marketMap = market_from_json(read_json($marketFile) ?: []);
    $source = 'json';
}

$items = [];
foreach ($rules['items'] as $item) {
    $market = $marketMap[$item['id']] ?? null;
    $price = null;
    if (is_int($market) && $market > 0) {
        $price = round_price($market * $margin, $step);
    }
    $row = $item;
    $row['market_toman'] = $market;
    $row['price'] = $price;
    $row['margin'] = $margin;
    $items[] = $row;
}

$payload = [
    'ok' => true,
    'cached' => false,
    'margin' => $margin,
    'source' => $source,
    'updated_ts' => $now,
    'updated_at' => date('Y-m-d H:i:s'),
    'whatsapp' => $config['whatsapp'] ?? '989365504590',
    'items' => $items,
];

write_json($outFile, $payload);
echo json_encode($payload, JSON_UNESCAPED_UNICODE);
