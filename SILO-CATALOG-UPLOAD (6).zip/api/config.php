<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$root = dirname(__DIR__);
$configPath = $root . '/config.json';
$modePath = $root . '/data/site-mode.json';
$config = [];
if (is_readable($configPath)) {
    $config = json_decode((string) file_get_contents($configPath), true) ?: [];
}
$mode = [];
if (is_readable($modePath)) {
    $mode = json_decode((string) file_get_contents($modePath), true) ?: [];
}

echo json_encode([
    'ok' => true,
    'catalog_only' => !empty($config['catalog_only']) || !empty($mode['catalog_only']),
    'whatsapp' => (string) ($config['whatsapp'] ?? $mode['whatsapp'] ?? '989117995099'),
], JSON_UNESCAPED_UNICODE);
