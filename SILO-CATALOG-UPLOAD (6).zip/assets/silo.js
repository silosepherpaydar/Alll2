const WA = "989365504590";
const SERVICE_WA = "989117995099";
let catalog = { items: [], catalog_only: false };
let siteMode = { catalog_only: Boolean(window.SILO_CATALOG_ONLY) };

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function faNum(n) {
  return Number(n).toLocaleString("fa-IR");
}

function priceText(item) {
  if (!item || !item.price) return "استعلام";
  return `${faNum(item.price)} تومان / ${item.unit}`;
}

function byId(id) {
  return catalog.items.find((x) => x.id === id);
}

function renderBoard() {
  const body = $("#board-body");
  const catalogMode = catalog.catalog_only || siteMode.catalog_only;
  if (body && catalog.items.length) {
    body.innerHTML = catalog.items
      .map((i) => {
        const ready = Boolean(i.price);
        const delta = ready
          ? "بازار + ۶٪"
          : (catalogMode ? "تماس / واتساپ" : "در انتظار نرخ پایه");
        return `<div class="row">
          <span class="exhibit">${i.exhibit}</span>
          <span>${i.name}</span>
          <span class="price">${ready ? faNum(i.price) + ' <span class="unit">تومان / ' + i.unit + "</span>" : "استعلام"}</span>
          <span class="delta flat">${delta}</span>
        </div>`;
      })
      .join("");
  }

  $$("[data-price]").forEach((el) => {
    const item = byId(el.dataset.price);
    el.textContent = priceText(item);
  });

  const upd = $("#updated");
  const src = $("#source");
  if (upd) upd.textContent = catalog.updated_at || (catalogMode ? "کاتالوگ" : "نرخ جاری");
  if (src) {
    src.textContent =
      catalogMode ? "کاتالوگ زنده" :
      catalog.source === "google-sheet" ? "گوگل‌شیت" :
      catalog.source === "demo" ? "پیش‌نمایش" : "کاتالوگ سیلو";
  }
}

function loadCafeLayer() {
  if (siteMode.catalog_only || document.querySelector("script[data-silo-cafe]")) {
    return;
  }
  const css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = "assets/silo-cafe.css?v=16";
  document.head.appendChild(css);
  const js = document.createElement("script");
  js.src = "assets/silo-cafe.js?v=16";
  js.dataset.siloCafe = "1";
  document.body.appendChild(js);
}

function hideCafeEntry() {
  const btn = $("#cafeEntryBtn");
  if (btn) btn.hidden = true;
  $("#cafeSheet")?.setAttribute("hidden", "hidden");
  $("#cafeOtp")?.setAttribute("hidden", "hidden");
  const userBtn = $("#userPanelBtn");
  if (userBtn) userBtn.hidden = false;
}

async function loadSiteMode() {
  if (window.SILO_CATALOG_ONLY) {
    siteMode.catalog_only = true;
    hideCafeEntry();
    return;
  }
  const urls = ["data/site-mode.json", "api/config.php"];
  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) continue;
      const data = await res.json();
      if (data && data.catalog_only) {
        siteMode.catalog_only = true;
        catalog.catalog_only = true;
        hideCafeEntry();
        return;
      }
    } catch (e) {
      /* next */
    }
  }
}

async function loadPrices() {
  if (location.protocol === "file:") return;
  const urls = ["api/prices.php", "data/prices.json"];
  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) continue;
      const data = await res.json();
      if (data && data.items) {
        catalog = data;
        if (data.catalog_only) {
          siteMode.catalog_only = true;
          hideCafeEntry();
        }
        renderBoard();
        const slider = $("#mix-slider");
        setMix(slider ? Number(slider.value) : 80);
        return;
      }
    } catch (e) {
      /* next */
    }
  }
}

const MIX_SNAPS = [80, 30, 20];

const mixMap = {
  80: {
    id: "arabica-100",
    tag: "تعادل ۸۰ / ۲۰",
    hero: "images/item-arabica100.jpg",
    focus: "center 42%",
    arabica: 80,
    robusta: 20,
  },
  30: {
    id: "harmony",
    tag: "میکس هارمونی",
    hero: "images/item-harmony.jpg",
    focus: "center 38%",
    arabica: 30,
    robusta: 70,
  },
  20: {
    id: "aflatoun",
    tag: "میکس افلاطون",
    hero: "images/item-aflatoun.jpg",
    focus: "72% 35%",
    arabica: 20,
    robusta: 80,
  },
};

function nearestMixSnap(raw) {
  return MIX_SNAPS.reduce((best, n) => (Math.abs(n - raw) < Math.abs(best - raw) ? n : best));
}

function setMix(pct) {
  const snap = nearestMixSnap(pct);
  const conf = mixMap[snap];
  if (!conf) return;

  const read = $("#mix-read");
  const price = $("#mix-price");
  const line = $("#mix-line");
  const tag = $("#mixPresetTag");
  const pctA = $("#mixPctA");
  const pctR = $("#mixPctR");
  const barA = $("#mixBarA");
  const barR = $("#mixBarR");

  if (barA) barA.style.flex = String(conf.arabica);
  if (barR) barR.style.flex = String(conf.robusta);
  if (pctA) pctA.textContent = `${faNum(conf.arabica)}٪`;
  if (pctR) pctR.textContent = `${faNum(conf.robusta)}٪`;

  const item = byId(conf.id);
  $$(".mix-tile, .mix-snaps button, .snaps button").forEach((btn) =>
    btn.classList.toggle("is-active", Number(btn.dataset.pct) === snap)
  );
  const slider = $("#mix-slider");
  if (slider) slider.value = String(snap);

  if (tag) tag.textContent = conf.tag;
  if (read) read.textContent = `${faNum(conf.arabica)}٪ عربیکا · ${faNum(conf.robusta)}٪ روبوستا`;
  if (price) price.textContent = priceText(item);
  if (line && item) line.textContent = item.line || "";
}

function bindMix() {
  $$(".mix-tile, .mix-snaps button, .snaps button[data-pct]").forEach((b) => {
    b.onclick = () => setMix(Number(b.dataset.pct));
  });
  const slider = $("#mix-slider");
  if (slider) {
    let raf = 0;
    slider.addEventListener("input", () => {
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setMix(Number(slider.value)));
    });
  }
  setMix(30);
}

function bindFloors() {
  const links = $$(".floors a");
  const map = links.map((a) => document.querySelector(a.getAttribute("href")));
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return;
        const i = map.indexOf(e.target);
        links.forEach((l, n) => l.classList.toggle("on", n === i));
      });
    },
    { threshold: 0.45 }
  );
  map.forEach((el) => el && io.observe(el));
}

/* ===================================================================
   FLAVOR RADAR & BATCH PASSPORT DATA
   =================================================================== */
const FLAVOR_DATA = {
  "arabica-100": {
    name: "عربیکا ۱۰۰٪ پریمیوم",
    code: "SILO-AR-100",
    origin: "آمریکای جنوبی / آفریقا",
    process: "Washed / فرآوری شسته",
    altitude: "۱۶۰۰ - ۱۸۵۰ متر",
    roast: "شکلاتی مخملی (Medium Roast)",
    moisture: "۱۰.۸٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 88 },
      { label: "عطر گل", val: 92 },
      { label: "بادی", val: 55 },
      { label: "کافئین", val: 45 },
      { label: "تلخی", val: 30 }
    ]
  },
  "ethiopia": {
    name: "عربیکا اتیوپی (یرگاچف)",
    code: "SILO-ET-001",
    origin: "یرگاچف، اتیوپی",
    process: "Washed / کاملاً شسته",
    altitude: "۱۹۰۰ - ۲۱۰۰ متر",
    roast: "شکلاتی روشن (City+)",
    moisture: "۱۱.۱٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 95 },
      { label: "عطر گل", val: 98 },
      { label: "بادی", val: 50 },
      { label: "کافئین", val: 40 },
      { label: "تلخی", val: 20 }
    ]
  },
  "colombia": {
    name: "عربیکا کلمبیا (سوپریمو)",
    code: "SILO-CO-001",
    origin: "هویلا، کلمبیا",
    process: "Washed / خیسانده",
    altitude: "۱۶۵۰ - ۱۹۰۰ متر",
    roast: "شکلات شیری (Medium)",
    moisture: "۱۰.۵٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 75 },
      { label: "عطر گل", val: 70 },
      { label: "بادی", val: 82 },
      { label: "کافئین", val: 50 },
      { label: "تلخی", val: 45 }
    ]
  },
  "aflatoun": {
    name: "میکس افلاطون (۸۰R / ۲۰A)",
    code: "SILO-MX-AFL",
    origin: "۸۰٪ روبوستا آسیایی / ۲۰٪ عربیکا کلمبیا",
    process: "Natural / Washed Blend",
    altitude: "۸۰۰ - ۱۷۰۰ متر",
    roast: "شکلاتی مخملی (Medium Roast)",
    moisture: "۱۰.۴٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 25 },
      { label: "عطر گل", val: 45 },
      { label: "بادی", val: 95 },
      { label: "کافئین", val: 92 },
      { label: "تلخی", val: 80 }
    ]
  },
  "harmony": {
    name: "میکس هارمونی (۷۰R / ۳۰A)",
    code: "SILO-MX-HAR",
    origin: "۷۰٪ روبوستا جاوا / ۳۰٪ عربیکا پریمیوم",
    process: "Balanced Blend",
    altitude: "۹۰۰ - ۱۸۰۰ متر",
    roast: "شکلاتی کلاسیک (Medium)",
    moisture: "۱۰.۶٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 40 },
      { label: "عطر گل", val: 65 },
      { label: "بادی", val: 88 },
      { label: "کافئین", val: 82 },
      { label: "تلخی", val: 68 }
    ]
  },
  "sumatra": {
    name: "میکس سوماترا (پایه روبوستا اندونزی)",
    code: "SILO-RB-SUM",
    origin: "پایه اندونزی + پی‌بی + چری + روبوستا هند اسکرین ۱۸",
    process: "میکس روبوستا؛ پایه اندونزی",
    altitude: "۸۰۰ - ۱۱۰۰ متر",
    roast: "مدیوم دارک (Medium Dark)",
    moisture: "۱۰.۰٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 20 },
      { label: "عطر گل", val: 40 },
      { label: "بادی", val: 94 },
      { label: "کافئین", val: 90 },
      { label: "تلخی", val: 82 }
    ]
  },
  "supernova": {
    name: "میکس سوپرنوآ (پایه روبوستا ویتنام)",
    code: "SILO-RB-SUP",
    origin: "پایه ویتنام + سه روبوستای دیگر + پی‌بی + چری",
    process: "میکس روبوستا؛ پایه ویتنام",
    altitude: "۶۰۰ - ۸۵۰ متر",
    roast: "مدیوم دارک (Medium Dark)",
    moisture: "۱۰.۴٪ استاندارد",
    metrics: [
      { label: "اسیدیته", val: 10 },
      { label: "عطر گل", val: 20 },
      { label: "بادی", val: 90 },
      { label: "کافئین", val: 95 },
      { label: "تلخی", val: 85 }
    ]
  },
  "vitali": {
    name: "میکس ویتالی (۵۰R / ۵۰A)",
    code: "SILO-MX-VIT",
    origin: "۵۰٪ روبوستا / ۵۰٪ عربیکا",
    process: "ترکیب اختصاصی سیلو",
    altitude: "۹۰۰ - ۱۷۰۰ متر",
    roast: "شکلاتی متوسط",
    moisture: "۱۰.۵٪",
    metrics: [
      { label: "اسیدیته", val: 55 },
      { label: "عطر گل", val: 68 },
      { label: "بادی", val: 78 },
      { label: "کافئین", val: 70 },
      { label: "تلخی", val: 52 }
    ]
  },
  "indo90": {
    name: "میکس اندونزی ۹۰/۱۰",
    code: "SILO-MX-I90",
    origin: "۹۰٪ روبوستا اندونزی / ۱۰٪ عربیکا",
    process: "پایه روبوستا سوماترا و جاوا",
    altitude: "۸۰۰ - ۱۲۰۰ متر",
    roast: "مدیوم‌دارک قهوه‌ای",
    moisture: "۱۰.۲٪",
    metrics: [
      { label: "اسیدیته", val: 22 },
      { label: "عطر گل", val: 35 },
      { label: "بادی", val: 93 },
      { label: "کافئین", val: 90 },
      { label: "تلخی", val: 78 }
    ]
  },
  "tata-gold": {
    name: "قهوه گلد هند تاتا",
    code: "SILO-GD-TATA",
    origin: "هند — تاتا",
    process: "فریزدرایر (گلد فوری)",
    altitude: "—",
    roast: "گلد؛ دانه رُست‌شده نیست",
    moisture: "خشک",
    metrics: [
      { label: "اسیدیته", val: 30 },
      { label: "عطر گل", val: 25 },
      { label: "بادی", val: 40 },
      { label: "کافئین", val: 60 },
      { label: "تلخی", val: 45 }
    ]
  }
};

function generate5DRadarSvg(metrics) {
  const N = 5;
  const cx = 48, cy = 48, r = 36;
  let bgPolys = "";
  for (let step = 1; step <= 3; step++) {
    const curR = (r / 3) * step;
    let pts = [];
    for (let i = 0; i < N; i++) {
      const angle = (Math.PI * 2 / N) * i - Math.PI / 2;
      pts.push(`${(cx + curR * Math.cos(angle)).toFixed(1)},${(cy + curR * Math.sin(angle)).toFixed(1)}`);
    }
    bgPolys += `<polygon points="${pts.join(" ")}" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" />`;
  }
  let dataPts = [];
  for (let i = 0; i < N; i++) {
    const angle = (Math.PI * 2 / N) * i - Math.PI / 2;
    const curR = (r * metrics[i].val) / 100;
    dataPts.push(`${(cx + curR * Math.cos(angle)).toFixed(1)},${(cy + curR * Math.sin(angle)).toFixed(1)}`);
  }
  const dataPoly = `<polygon points="${dataPts.join(" ")}" fill="rgba(255,87,20,0.28)" stroke="#ff5714" stroke-width="2" />`;
  return `<svg class="mini-radar-svg" viewBox="0 0 96 96">${bgPolys}${dataPoly}</svg>`;
}

function compactCatalogCards() {
  $$("#beans .prod-card").forEach((card) => {
    if (card.dataset.compactDone === "1") return;
    const body = card.querySelector(".prod-body");
    const actions = card.querySelector(".prod-actions");
    if (!body || !actions) return;

    const embed = card.querySelector(".card-radar-embed");
    const calib = card.querySelector(".calib-card");
    const desc = card.querySelector(".prod-desc");
    const meta = actions.querySelector(".meta");
    const btnWrap = actions.querySelector("div[style], .prod-action-btns");
    const addBtn = actions.querySelector(".btn-add-to-cart");
    const extraBtns = actions.querySelectorAll(".btn-passport");

    const details = document.createElement("details");
    details.className = "prod-more";
    const summary = document.createElement("summary");
    summary.innerHTML = '<span class="prod-more-star" aria-hidden="true">★</span> جزئیات (رادار، کالیبر، مقایسه، شناسنامه)';
    const moreBody = document.createElement("div");
    moreBody.className = "prod-more-body";
    if (desc) moreBody.appendChild(desc);
    if (embed) moreBody.appendChild(embed);
    if (calib) moreBody.appendChild(calib);
    if (extraBtns.length) {
      const row = document.createElement("div");
      row.className = "prod-more-actions";
      extraBtns.forEach((b) => row.appendChild(b));
      moreBody.appendChild(row);
    }
    details.appendChild(summary);
    details.appendChild(moreBody);

    actions.innerHTML = "";
    actions.classList.add("prod-actions--compact");
    if (meta) actions.appendChild(meta);
    if (addBtn) {
      addBtn.textContent = "افزودن به سبد";
      actions.appendChild(addBtn);
    }
    body.insertBefore(details, actions);
    card.dataset.compactDone = "1";
  });
}

function bindFlavorRadars() {
  Object.keys(FLAVOR_DATA).forEach((key) => {
    const embed = $(`#embed-${key}`);
    const data = FLAVOR_DATA[key];
    if (!embed || !data) return;
    const svgHtml = generate5DRadarSvg(data.metrics);
    const barsHtml = data.metrics.map(m => `
      <div class="f-bar-row">
        <span class="f-bar-label">${m.label}</span>
        <div class="f-bar-track"><div class="f-bar-fill" style="width:${m.val}%"></div></div>
        <span class="f-bar-val">${faNum(m.val)}٪</span>
      </div>
    `).join("");
    embed.innerHTML = `
      ${svgHtml}
      <div class="mini-radar-bars">${barsHtml}</div>
    `;
  });
}

/* ===================================================================
   BATCH PASSPORT MODAL
   =================================================================== */
function openPassport(key) {
  const data = FLAVOR_DATA[key];
  if (!data) return;
  $("#passCode").textContent = data.code;
  $("#passTitle").textContent = data.name;
  $("#passGrid").innerHTML = `
    <div class="passport-item"><span class="k">خاستگاه و منطقه:</span><span class="v">${data.origin}</span></div>
    <div class="passport-item"><span class="k">فرآوری دانه:</span><span class="v">${data.process}</span></div>
    <div class="passport-item"><span class="k">ارتفاع مزرعه:</span><span class="v">${data.altitude}</span></div>
    <div class="passport-item"><span class="k">پروفایل رُست:</span><span class="v">${data.roast}</span></div>
    <div class="passport-item"><span class="k">رطوبت دانه سبز:</span><span class="v">${data.moisture}</span></div>
    <div class="passport-item"><span class="k">واحد بسته‌بندی:</span><span class="v">کیسه ۱ و ۱۰ کیلو سوپاپ‌دار</span></div>
  `;
  const modal = $("#passportModal");
  if (modal) modal.classList.add("open");
}

function closePassport(e) {
  if (!e || e.target === $("#passportModal") || e.target.classList.contains("passport-close")) {
    $("#passportModal")?.classList.remove("open");
  }
}

function bindPassportButtons() {
  $$("[data-passport]").forEach(btn => {
    btn.onclick = () => openPassport(btn.dataset.passport);
  });
}

/* ===================================================================
   IDEA 3: DUAL FLAVOR COMPARISON
   =================================================================== */
let compareQueue = [];

function toggleCompare(key) {
  const idx = compareQueue.indexOf(key);
  if (idx >= 0) {
    compareQueue.splice(idx, 1);
  } else {
    if (compareQueue.length >= 2) compareQueue.shift();
    compareQueue.push(key);
  }
  updateCompareBar();
}

function updateCompareBar() {
  const bar = $("#compareBar");
  const text = $("#compareText");
  if (!bar) return;
  if (compareQueue.length === 1) {
    bar.classList.add("show");
    text.textContent = `۱ دانه (${FLAVOR_DATA[compareQueue[0]].name}) انتخاب شد؛ دانهٔ دوم را انتخاب کنید.`;
  } else if (compareQueue.length === 2) {
    bar.classList.add("show");
    text.textContent = `آماده: ${FLAVOR_DATA[compareQueue[0]].name} ⚔️ ${FLAVOR_DATA[compareQueue[1]].name}`;
  } else {
    bar.classList.remove("show");
  }
}

function openCompareModal() {
  if (compareQueue.length < 2) return;
  const d1 = FLAVOR_DATA[compareQueue[0]];
  const d2 = FLAVOR_DATA[compareQueue[1]];
  const grid = $("#compareGrid");
  if (!grid) return;

  function makeCol(data) {
    const svg = generate5DRadarSvg(data.metrics);
    const bars = data.metrics.map(m => `
      <div class="f-bar-row">
        <span class="f-bar-label">${m.label}</span>
        <div class="f-bar-track"><div class="f-bar-fill" style="width:${m.val}%"></div></div>
        <span class="f-bar-val">${faNum(m.val)}٪</span>
      </div>
    `).join("");
    return `
      <div class="compare-col">
        <h4>${data.name}</h4>
        <div style="display:flex;gap:14px;align-items:center;margin-bottom:12px">
          ${svg}
          <div style="flex:1">${bars}</div>
        </div>
        <p style="font-size:13px;color:var(--paper-dim);line-height:1.7;margin:0">${data.origin} • ${data.process}</p>
      </div>
    `;
  }

  grid.innerHTML = makeCol(d1) + makeCol(d2);
  $("#compareModal")?.classList.add("open");
}

function closeCompareModal(e) {
  if (!e || e.target === $("#compareModal") || e.target.classList.contains("passport-close")) {
    $("#compareModal")?.classList.remove("open");
  }
}

/* ===================================================================
   CAFE RECOMMENDER ENGINE
   =================================================================== */
const RECOMMENDS = {
  "busy": {
    title: "ترکیب پیشنهادی: میکس افلاطون (۸۰/۲۰) یا سوماترا",
    desc: "برای کافه‌های پرمشتری که سرعت شیفت بالاست و نوشیدنی‌های با شیر (لاته و کاپوچینو) بخش اعظم سفارشات را تشکیل می‌دهند. این میکس کرمای بسیار غلیظ، کافئین فراوان و طعم پایدار را با هزینهٔ اقتصادی تضمین می‌کند.",
    badges: ["کرمای حداکثری", "کافئین بالا", "میکس افلاطون", "پایداری با شیر"],
    btnText: "سفارش بسته تست میکس افلاطون"
  },
  "specialty": {
    title: "ترکیب پیشنهادی: اتیوپی یرگاچف + کلمبیا سوپریمو",
    desc: "مخصوص کافه‌های موج سوم و مشتریانی که به دنبال طعم‌یادهای پیچیده گلی، اسیدیته زنده مرکباتی و بادی مخملی در متدهای دمی دستی (V60، کمکس) و اسپرسوی خالص هستند.",
    badges: ["اسپیشیالتی گرید ۸۵+", "اسیدیته زنده", "عطر گل و کارامل", "بدون تلخی گزنده"],
    btnText: "درخواست سمپل بار تخصصی"
  },
  "takeaway": {
    title: "ترکیب پیشنهادی: میکس هارمونی (۷۰/۳۰) یا سوپرنوآ",
    desc: "طراحی‌شده برای بارهای بیرون‌بر و تیک‌اوی؛ طعم پرقدرت اسپرسو از پشت لایه‌های یخ و شیر به خوبی حس می‌شود و هارمونی بی‌نظیری از فوم و عطر خلق می‌کند.",
    badges: ["گیرایی بالا در آیس کافی", "فوم ماندگار", "میکس هارمونی"],
    btnText: "استعلام سفارش عمده میکس هارمونی"
  }
};

function bindRecommender() {
  const tabs = $$(".recom-tab");
  const box = $("#recomContent");
  if (!tabs.length || !box) return;

  function render(key) {
    const data = RECOMMENDS[key];
    if (!data) return;
    tabs.forEach(t => t.classList.toggle("active", t.dataset.recom === key));
    box.innerHTML = `
      <div>
        <div class="recom-title">${data.title}</div>
        <div class="recom-desc">${data.desc}</div>
        <div class="recom-badges">
          ${data.badges.map(b => `<span class="recom-badge">✓ ${b}</span>`).join("")}
        </div>
      </div>
      <div>
        <a class="recom-btn" href="https://wa.me/${WA}?text=${encodeURIComponent('سلام سیلو، پیرو پیشنهاد دانه برای ' + data.title + ' نیاز به مشاوره و سفارش داشتم.')}" target="_blank" rel="noopener">
          ${data.btnText}
        </a>
      </div>
    `;
  }
  tabs.forEach(t => {
    t.onclick = () => {
      render(t.dataset.recom);
      $("#beans")?.scrollIntoView({ behavior: "smooth", block: "start" });
    };
  });
  render("busy");
}

/* ===================================================================
   CUP PROFIT CALCULATOR ENGINE (EXACT BENCHMARK: 21,000,000 Rials / 55 Shots / 38,500 Toman/Shot)
   =================================================================== */
function parseFaNumberInput(el) {
  if (!el) return 0;
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  let s = String(el.value || "").trim();
  for (let i = 0; i < fa.length; i++) s = s.split(fa[i]).join(String(i));
  s = s.replace(/[^\d.]/g, "");
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function formatFaInputValue(el) {
  if (!el) return;
  const raw = String(el.value || "").trim();
  if (!raw) return;
  const n = parseFaNumberInput(el);
  if (n > 0) el.value = faNum(Math.round(n));
}

function bindFaMoneyInputs(inputs, onChange) {
  inputs.forEach((el) => {
    if (!el) return;
    el.addEventListener("focus", () => {
      const n = parseFaNumberInput(el);
      el.value = n > 0 ? String(Math.round(n)) : "";
    });
    el.addEventListener("blur", () => {
      formatFaInputValue(el);
      onChange?.();
    });
    el.addEventListener("input", () => {
      const n = parseFaNumberInput(el);
      if (String(el.value || "").trim() && n > 0) el.value = faNum(Math.round(n));
      onChange?.();
    });
  });
}

function bindProfitCalculator() {
  const slider = $("#cupsSlider");
  const badge = $("#cupsBadge");
  const kgEl = $("#calcKg");
  const shotCostEl = $("#calcShotCost");
  const profitEl = $("#calcProfit");
  const costShotIn = $("#calcCostPerShot");
  const sellShotIn = $("#calcSellPerShot");
  const costKgIn = $("#calcCostPerKg");
  if (!slider) return;

  const SHOTS_PER_KG = 55;

  function updateCalc() {
    const cupsPerDay = Number(slider.value);
    if (badge) badge.textContent = `${faNum(cupsPerDay)} شات روزانه`;

    const kgPerDay = (cupsPerDay / SHOTS_PER_KG).toFixed(1);
    if (kgEl) kgEl.textContent = `${faNum(Number(kgPerDay))} کیلوگرم`;

    let costPerShot = parseFaNumberInput(costShotIn);
    const costPerKg = parseFaNumberInput(costKgIn);
    if (costPerShot <= 0 && costPerKg > 0) {
      costPerShot = Math.round(costPerKg / SHOTS_PER_KG);
    }
    if (costPerShot <= 0) costPerShot = 38500;

    let sellPerShot = parseFaNumberInput(sellShotIn);
    if (sellPerShot <= 0) sellPerShot = 85000;

    if (shotCostEl) shotCostEl.textContent = `${faNum(Math.round(costPerShot))} تومان`;
    const netPerShot = sellPerShot - costPerShot;
    const netProfitPerDay = cupsPerDay * netPerShot;
    if (profitEl) profitEl.textContent = `${faNum(Math.round(netProfitPerDay))} تومان`;
  }

  slider.addEventListener("input", updateCalc);
  bindFaMoneyInputs([costShotIn, sellShotIn, costKgIn], updateCalc);
  [costShotIn, sellShotIn, costKgIn].forEach((el) => formatFaInputValue(el));
  updateCalc();
}

/* ===================================================================
   MACHINE DIAGNOSTIC SYSTEM (DOCTOR ENGINE)
   =================================================================== */
const DIAGNOSTICS = [
  {
    id: "sour-shot",
    title: "⚡ شات ترش، آبکی و کم‌عصاره",
    symptom: "زمان ریزش اسپرسو زیر ۱۵ ثانیه تمام شده و عصاره طعم بیش از حد گس و ترش دارد.",
    cause: "سایز پودر بیش از حد درشت است، پودر به صورت یکنواخت تمپ نشده یا شیارهای بسکت و واشر دچار فرسایش شده‌اند.",
    act: "کالیبراسیون فوری تیغه‌های آسیاب، استفاده از بسکت استاندارد VST یا تعویض واشر ۸mm.",
    msg: "سلام مهندس پوراحمدی، عصاره‌گیری دستگاه ما زیر ۱۵ ثانیه آبکی و ترش خارج می‌شه. برای کالیبراسیون آسیاب یا واشر راهنمایی می‌خواستم."
  },
  {
    id: "weak-steam",
    title: "💨 فشار بخار ضعیف یا آبکی",
    symptom: "نازل بخار توان ایجاد فوم مخملی ریز را ندارد و آب جوش وارد پیچر شیر می‌کند.",
    cause: "انباشت رسوب کلسیم در مدار بویلر بخار، گرفتگی روزنه‌های نازل یا نیم‌سوز شدن شیر برقی ۳‌راهه ODE.",
    act: "رسوب‌زدایی مدار بخار، تمیزکاری اولتراسونیک سری نازل و تست شیر برقی.",
    msg: "سلام مهندس پوراحمدی، نازل بخار دستگاه ما ضعیف شده و فوم درست نمی‌ده. برای سرویس مدار بخار هماهنگ بفرمایید."
  },
  {
    id: "burnt-smell",
    title: "🔥 دمای بیش از حد و بوی سوختگی",
    symptom: "آب جوش خروجی دارای حباب‌های سوزاننده است و عطر قهوه سوخته به نظر می‌رسد.",
    cause: "خطای سنسور دمای NTC، چسبیدن رله حرارتی بویلر یا تنظیم نبودن پارامتر PID دمایی.",
    act: "تست و تعویض سنسور NTC و کالیبراسیون مجدد ترموستات بویلر.",
    msg: "سلام مهندس پوراحمدی، دمای بویلر دستگاه ما خیلی بالا رفته و بوی سوختگی میده. برای بررسی سنسور NTC کمک می‌خواستم."
  },
  {
    id: "leak-group",
    title: "💧 نشتی آب از اطراف پرتافیلتر",
    symptom: "در حین عصاره‌گیری ۹ بار، قطرات آب داغ از دور هدگروپ سرازیر می‌شوند.",
    cause: "خشک و شکننده شدن واشر سیلیکونی هدگروپ در اثر حرارت طولانی‌مدت شیفت کاری.",
    act: "تعویض واشر سیلیکونی فودگرید استاندارد ۸ میلی‌متری.",
    msg: "سلام مهندس پوراحمدی، از دور پرتافیلتر دستگاه ما نشتی آب وجود داره. واشر سیلیکونی هدگروپ موجود دارین؟"
  }
];

function bindDoctor() {
  const tabs = $("#docTabs");
  const result = $("#docResult");
  if (!tabs || !result) return;
  tabs.innerHTML = DIAGNOSTICS.map((d, idx) => `
    <button class="doc-tab ${idx === 0 ? 'active' : ''}" data-doc="${d.id}" type="button">${d.title}</button>
  `).join("");

  function showDoc(id) {
    const d = DIAGNOSTICS.find(x => x.id === id);
    if (!d) return;
    $$(".doc-tab").forEach(btn => btn.classList.toggle("active", btn.dataset.doc === id));
    result.innerHTML = `
      <div class="doc-symptom">${d.title}</div>
      <div class="doc-cause"><b>ریشهٔ عیب فنی:</b> ${d.cause}</div>
      <div class="doc-cause"><b>راهکار تخصصی سیلو:</b> ${d.act}</div>
      <a class="doc-act-btn" href="https://wa.me/${SERVICE_WA}?text=${encodeURIComponent(d.msg)}" target="_blank" rel="noopener">
        <span>ارسال مستقیم مشکل به واتساپ مهندس پوراحمدی</span>
        <span>💬</span>
      </a>
    `;
  }
  tabs.onclick = (e) => {
    const btn = e.target.closest(".doc-tab");
    if (btn) showDoc(btn.dataset.doc);
  };
  showDoc(DIAGNOSTICS[0].id);
}

/* ===================================================================
   AMBIENT AUDIO SYNTHESIZER
   =================================================================== */
let audioCtx = null;
let soundNodes = [];
let isPlaying = false;

function initAudio() {
  if (audioCtx) return;
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  audioCtx = new AudioContext();
}

function startAmbientSound() {
  initAudio();
  if (!audioCtx) return;
  if (audioCtx.state === 'suspended') audioCtx.resume();

  const osc = audioCtx.createOscillator();
  const oscGain = audioCtx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(60, audioCtx.currentTime);
  oscGain.gain.setValueAtTime(0.06, audioCtx.currentTime);
  osc.connect(oscGain);
  oscGain.connect(audioCtx.destination);
  osc.start();
  soundNodes.push(osc, oscGain);

  const bufferSize = audioCtx.sampleRate * 2;
  const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  let b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99886 * b0 + white * 0.0555179;
    b1 = 0.99332 * b1 + white * 0.0750759;
    b2 = 0.96900 * b2 + white * 0.1538520;
    output[i] = (b0 + b1 + b2 + white * 0.05) * 0.09;
  }
  const noiseSource = audioCtx.createBufferSource();
  noiseSource.buffer = noiseBuffer;
  noiseSource.loop = true;

  const filter = audioCtx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(400, audioCtx.currentTime);

  const noiseGain = audioCtx.createGain();
  noiseGain.gain.setValueAtTime(0.04, audioCtx.currentTime);

  noiseSource.connect(filter);
  filter.connect(noiseGain);
  noiseGain.connect(audioCtx.destination);
  noiseSource.start();
  soundNodes.push(noiseSource, filter, noiseGain);
  isPlaying = true;
}

function stopAmbientSound() {
  soundNodes.forEach(node => {
    try { if (node.stop) node.stop(); } catch(e){}
    try { if (node.disconnect) node.disconnect(); } catch(e){}
  });
  soundNodes = [];
  isPlaying = false;
}

function bindSoundToggle() {
  const btn = $("#soundToggle");
  const icon = $("#soundIcon");
  const text = $("#soundText");
  if (!btn) return;
  btn.onclick = () => {
    if (!isPlaying) {
      startAmbientSound();
      btn.classList.add("playing");
      if (icon) icon.textContent = "🔊";
      if (text) text.textContent = "اتمسفر سیلو (روشن)";
    } else {
      stopAmbientSound();
      btn.classList.remove("playing");
      if (icon) icon.textContent = "🔇";
      if (text) text.textContent = "صدای سیلو";
    }
  };
}

/* ===================================================================
   SPOTLIGHT
   =================================================================== */
function bindSpotlight() {
  const spot = $("#spotlight");
  if (!spot) return;
  window.addEventListener("pointermove", (e) => {
    const x = (e.clientX / window.innerWidth) * 100;
    const y = (e.clientY / window.innerHeight) * 100;
    document.documentElement.style.setProperty("--mouse-x", `${x.toFixed(1)}%`);
    document.documentElement.style.setProperty("--mouse-y", `${y.toFixed(1)}%`);
  });
}

/* ===================================================================
   DIVINATION / COFFEE ORACLE ENGINE (DYNAMIC PROCEDURAL NARRATIVE)
   =================================================================== */
let selectedOracleBean = "dark";

// Procedural narrative generator matrices (Over 10,000+ unique atmospheric combinations)
const ORACLE_SYMBOLS = [
  { symbol: "👁️", name: "چشم بینا", force: "بصیرت و شهود درونی" },
  { symbol: "⚙️", name: "چرخ‌دندهٔ سرنوشت", force: "شالوده‌شکنی و بازسازی" },
  { symbol: "🔥", name: "شعلهٔ کیمیا", force: "اشتیاق و گدازش موانع" },
  { symbol: "🌙", name: "هلال نیمه‌شب", force: "آرامش و راز" },
  { symbol: "⚡", name: "آذرخش سحرگاهی", force: "انرژی و تکانهٔ ناگهانی" },
  { symbol: "⏳", name: "ساعت شنی ازل", force: "صبر و بلوغ زمان" },
  { symbol: "🦅", name: "عقاب بال‌گشوده", force: "اوج‌گیری و تسلط بر بازار" },
  { symbol: "🗝️", name: "کلید برنجی کهن", force: "گشایش درهای مسدود" },
  { symbol: "🌊", name: "جزر و مد تاریک", force: "پایداری در طوفان شیفت" },
  { symbol: "🌿", name: "شاخهٔ جاودان", force: "اصالت، ریشه و پیوستگی" }
];

const NARRATIVE_OPENINGS = [
  "«پردهٔ غبارآلود زمان برایت به کناری رفت.",
  "«در خطوط پیچ‌خوردهٔ تفاله، رازی نهفته آشکار گشت.",
  "«نجوای سحرگاهی سیلو پیام روشنی به مدار تو رساند.",
  "«امواج دانه و آتش سرنوشت را بر صفحهٔ تقدیر نقش زدند.",
  "«در سکوت بعد از آخرین جرعه، چشم حقیقت گشوده شد.",
  "«نیروی اصیل برشتگی مسیری نامنتظر را پیش رویت نهاد."
];

const NARRATIVE_CORES = [
  "نظمی که پیش‌تر در آن سردرگم بودی، اکنون با دستان خودت به قدرتی بی‌سابقه مبدل می‌شود.",
  "تصمیمی که در سکوت امروز اتخاذ می‌کنی، ستون‌های موفقیت و پایداری فردایت را بنا خواهد کرد.",
  "موجی از انرژی خستگی‌ناپذیر و برکت کاری به شیفت‌های تو سرازیر خواهد شد.",
  "چالشی که به ظاهر مانع می‌پنداشتی، همان گذرگاه اصلی برای جهش و درخشش بار توست.",
  "آنچه در ظرافت، کیفیت و وفاداری به مشتری سرمایه‌گذاری کردی، به اعتباری بی‌پایان تبدیل می‌شود.",
  "یک گفتگوی به ظاهر تصادفی یا دیداری غیرمنتظره، کلید گشایش یک گره کاری خواهد بود."
];

const NARRATIVE_ACTIONS = [
  "به شم درونی‌ات ایمان داشته باش؛ شات امروزت طعم فتح فردا را دارد.»",
  "تردید را در آتش دانه‌ها بسوزان و با قاطعیت اولین قدم را بردار.»",
  "ثبات و استاندارد را رها مکن؛ پیروزی از آنِ مداومت‌کنندگان است.»",
  "دستگاه‌ها را آماده کن؛ فصلی پررونق و پرفنجان در انتظار بار توست.»",
  "پرچم کیفیت را بالا نگه دار؛ مخاطبان خاص، راه کافه‌ات را به زودی خواهند یافت.»"
];

const ORACLE_COFFEE_MATCHES = [
  { name: "میکس افلاطون (۸۰ روبوستا / ۲۰ عربیکا)", reason: "برای تقویت ایستادگی، کرمای سرکش و کافئین تمرکزآفرین" },
  { name: "میکس هارمونی (۷۰ روبوستا / ۳۰ عربیکا)", reason: "جهت ایجاد تعادل کامل، هارمونی طعم و انرژی روزمره" },
  { name: "میکس سوماترا (پایه اندونزی، پی‌بی و چری)", reason: "همگام با بادی متراکم، تلخی اصیل و شکستن موانع شیفت" },
  { name: "عربیکا اتیوپی یرگاچف", reason: "هماهنگ با بصیرت میوه‌ای، عطر گل یاس و تفکر خلاق موج سوم" },
  { name: "عربیکا کلمبیا سوپریمو", reason: "برای خلق شیرینی کاراملی، آرامش و پایداری طولانی‌مدت بار" },
  { name: "میکس سوپرنوآ (پایه ویتنام، پی‌بی و چری)", reason: "انفجار شارژ انرژی و سرعت در پاسخ به سفارشات سنگین" }
];

const ORACLE_BEAN_MATCHES = {
  dark: [0, 2],
  light: [3, 4],
  espresso: [5, 1]
};

function generateProceduralProphecy() {
  const sym = ORACLE_SYMBOLS[Math.floor(Math.random() * ORACLE_SYMBOLS.length)];
  const open = NARRATIVE_OPENINGS[Math.floor(Math.random() * NARRATIVE_OPENINGS.length)];
  const core = NARRATIVE_CORES[Math.floor(Math.random() * NARRATIVE_CORES.length)];
  const act = NARRATIVE_ACTIONS[Math.floor(Math.random() * NARRATIVE_ACTIONS.length)];
  const pool = ORACLE_BEAN_MATCHES[selectedOracleBean] || [0, 1, 2, 3, 4, 5];
  const coffee = ORACLE_COFFEE_MATCHES[pool[Math.floor(Math.random() * pool.length)]];

  const fullText = `${open} ${core} ${act}`;
  return {
    symbol: sym.symbol,
    name: sym.name,
    force: sym.force,
    prophecy: fullText,
    rec: `☕ دانه هماهنگ با این طالع: ${coffee.name} (${coffee.reason})`
  };
}

function openOracleModal() {
  resetOracleDivination();
  $("#oracleModal")?.classList.add("open");
}

function closeOracleModal(e) {
  if (!e || e.target === $("#oracleModal") || e.target.classList.contains("oracle-close")) {
    $("#oracleModal")?.classList.remove("open");
  }
}

function selectOracleBean(type, el) {
  selectedOracleBean = type;
  $$(".oracle-bean-opt").forEach(opt => opt.classList.remove("selected"));
  el.classList.add("selected");
  playOracleTap(type);
}

function oracleAudioReady() {
  initAudio();
  if (!audioCtx) return null;
  if (audioCtx.state === "suspended") audioCtx.resume();
  return audioCtx;
}

function oracleBell(ctx, dest, freq, when, dur, level) {
  const partials = [[1, 1], [2.01, 0.35], [3.02, 0.14]];
  partials.forEach(([mult, amp]) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq * mult, when);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(level * amp, when + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(g);
    g.connect(dest);
    osc.start(when);
    osc.stop(when + dur + 0.05);
  });
}

function oracleEchoBus(ctx, time, feedback) {
  const input = ctx.createGain();
  const delay = ctx.createDelay(1.5);
  const fb = ctx.createGain();
  const tone = ctx.createBiquadFilter();
  const out = ctx.createGain();
  delay.delayTime.setValueAtTime(time, ctx.currentTime);
  fb.gain.setValueAtTime(feedback, ctx.currentTime);
  tone.type = "lowpass";
  tone.frequency.setValueAtTime(2600, ctx.currentTime);
  out.gain.setValueAtTime(0.85, ctx.currentTime);
  input.connect(out);
  input.connect(delay);
  delay.connect(tone);
  tone.connect(fb);
  fb.connect(delay);
  tone.connect(out);
  out.connect(ctx.destination);
  return input;
}

function playOracleTap(type) {
  const ctx = oracleAudioReady();
  if (!ctx) return;
  try {
    const t = ctx.currentTime;
    const bus = oracleEchoBus(ctx, 0.18, 0.32);
    const base = { dark: 392, light: 659.3, espresso: 523.3 }[type] || 523.3;
    oracleBell(ctx, bus, base, t, 1.1, 0.12);
    oracleBell(ctx, bus, base * 1.5, t + 0.09, 1.2, 0.08);
  } catch (e) {}
}

function playOracleRitual() {
  const ctx = oracleAudioReady();
  if (!ctx) return;
  try {
    const t = ctx.currentTime;
    const total = 5.6;
    const bus = oracleEchoBus(ctx, 0.32, 0.42);

    const pad = ctx.createGain();
    const padFilter = ctx.createBiquadFilter();
    padFilter.type = "lowpass";
    padFilter.frequency.setValueAtTime(260, t);
    padFilter.frequency.linearRampToValueAtTime(1400, t + 3.2);
    padFilter.frequency.linearRampToValueAtTime(500, t + total);
    pad.gain.setValueAtTime(0.0001, t);
    pad.gain.linearRampToValueAtTime(0.07, t + 1.1);
    pad.gain.setValueAtTime(0.07, t + 3.8);
    pad.gain.exponentialRampToValueAtTime(0.0001, t + total);
    padFilter.connect(pad);
    pad.connect(bus);
    [110, 164.8, 220.4, 329.2].forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = i % 2 ? "triangle" : "sawtooth";
      o.frequency.setValueAtTime(f, t);
      o.detune.setValueAtTime(i % 2 ? 7 : -7, t);
      const g = ctx.createGain();
      g.gain.setValueAtTime(i === 0 ? 0.5 : 0.28, t);
      o.connect(g);
      g.connect(padFilter);
      o.start(t);
      o.stop(t + total + 0.1);
    });

    const len = Math.floor(ctx.sampleRate * total);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const swirl = ctx.createBufferSource();
    swirl.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.setValueAtTime(6, t);
    bp.frequency.setValueAtTime(260, t);
    bp.frequency.exponentialRampToValueAtTime(2400, t + 2.6);
    bp.frequency.exponentialRampToValueAtTime(380, t + 4.4);
    const sg = ctx.createGain();
    sg.gain.setValueAtTime(0.0001, t);
    sg.gain.linearRampToValueAtTime(0.09, t + 1.4);
    sg.gain.exponentialRampToValueAtTime(0.0001, t + 4.6);
    swirl.connect(bp);
    bp.connect(sg);
    sg.connect(bus);
    swirl.start(t);
    swirl.stop(t + total);

    const scale = [440, 466.2, 554.4, 587.3, 659.3, 698.5, 880];
    scale.forEach((f, i) => oracleBell(ctx, bus, f, t + 0.45 + i * 0.36, 1.8, 0.07));

    const reveal = t + 3.95;
    [880, 1108.7, 1318.5].forEach((f, i) => oracleBell(ctx, bus, f, reveal + i * 0.05, 2.4, 0.09));
    oracleBell(ctx, bus, 220, reveal, 2.2, 0.12);
  } catch (e) {
    console.log("Audio error:", e);
  }
}

function startOracleDivination() {
  $("#oracleStage1").style.display = "none";
  $("#oracleStage2").style.display = "block";
  $("#oracleStage3").style.display = "none";

  playOracleRitual();

  setTimeout(() => {
    // Generate fresh procedural prophecy dynamically
    const outcome = generateProceduralProphecy();
    
    $("#oracleSymbol").textContent = outcome.symbol;
    $("#oracleSymbolName").textContent = outcome.name;
    $("#oracleProphecy").textContent = outcome.prophecy;
    $("#oracleCoffeeRec").textContent = outcome.rec;

    const shareMsg = `طالع من در محفل مخفی سیلو (سایه در فنجان):\n${outcome.symbol} ${outcome.name}\n${outcome.prophecy}\nپیشگویی فنجان خودت را در silosepher.ir ببین!`;
    $("#oracleShareWa").href = `https://wa.me/?text=${encodeURIComponent(shareMsg)}`;

    $("#oracleStage2").style.display = "none";
    $("#oracleStage3").style.display = "block";
  }, 4000);
}

function resetOracleDivination() {
  $("#oracleStage1").style.display = "grid";
  $("#oracleStage2").style.display = "none";
  $("#oracleStage3").style.display = "none";
}

/* ===================================================================
   4. SILO 13-SECOND ACADEMY REAL-TIME CANVAS ANIMATOR (IDEA 4)
   =================================================================== */
let academyTimers = {};
let academyAnimFrames = {};

function initAcademyCanvases() {
  [1, 2, 3].forEach(num => {
    const canvas = $(`#canvasAcad${num}`);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    drawAcademyIdleFrame(ctx, num);
  });
}

function drawAcademyIdleFrame(ctx, num) {
  const w = 360, h = 200;
  ctx.fillStyle = "#16171b";
  ctx.fillRect(0, 0, w, h);

  if (num === 1) {
    // Grinder Hopper & Burrs diagram
    ctx.strokeStyle = "rgba(255, 87, 20, 0.4)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(140, 30);
    ctx.lineTo(220, 30);
    ctx.lineTo(195, 90);
    ctx.lineTo(165, 90);
    ctx.closePath();
    ctx.stroke();

    ctx.fillStyle = "#ff5714";
    ctx.fillRect(160, 95, 40, 20); // Grinder collar

    ctx.fillStyle = "rgba(255,255,255,0.2)";
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(170 + (i % 3) * 10, 50 + Math.floor(i / 3) * 15, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (num === 2) {
    // Milk Pitcher & Vortex
    ctx.strokeStyle = "rgba(255, 120, 54, 0.5)";
    ctx.lineWidth = 2;
    ctx.strokeRect(145, 60, 70, 90);

    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(130, 40);
    ctx.lineTo(170, 95);
    ctx.stroke(); // Steam wand at 45 deg

    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.fillRect(150, 95, 60, 50);
  } else if (num === 3) {
    // Grouphead & Backflush basket
    ctx.fillStyle = "#26282e";
    ctx.fillRect(130, 40, 100, 30); // Grouphead

    ctx.strokeStyle = "#0ea5e9";
    ctx.lineWidth = 2;
    ctx.strokeRect(145, 75, 70, 40); // Blind basket

    ctx.fillStyle = "rgba(14, 165, 233, 0.3)";
    ctx.fillRect(150, 80, 60, 30);
  }
}

function playAcademyDemo(videoNum) {
  const canvas = $(`#canvasAcad${videoNum}`);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = 360, h = 200;

  const frame = $(`#acadFrame${videoNum}`);
  const progEl = $(`#acadProg${videoNum}`);
  const subEl = $(`#acadSub${videoNum}`);

  if (academyTimers[videoNum]) clearInterval(academyTimers[videoNum]);
  if (academyAnimFrames[videoNum]) cancelAnimationFrame(academyAnimFrames[videoNum]);

  if (frame) frame.classList.add("playing");

  let startTime = Date.now();
  const totalDuration = 13000; // 13 seconds

  const subtitles = {
    1: [
      { t: 0, s: "مرحله ۱ (۰-۳s): هوای شرجی سابه را در هاپر متورم می‌کند." },
      { t: 3, s: "مرحله ۲ (۳-۷s): پیچ تنظیم تیغه را ۰.۴ درجه درشت‌تر بچرخانید." },
      { t: 7, s: "مرحله ۳ (۷-۱۰s): آب داخل پرتافیلتر را با دستمال میکروفایبر خشک کنید." },
      { t: 10, s: "مرحله ۴ (۱۰-۱۳s): شات ایده‌آل ۲۶ ثانیه‌ای با کرمای فندقی و بدون چنلینگ!" }
    ],
    2: [
      { t: 0, s: "مرحله ۱ (۰-۳s): نازل بخار را با زاویه ۴۵ درجه در گوشه پیچر غوطه‌ور کنید." },
      { t: 3, s: "مرحله ۲ (۳-۷s): شیر را با چرخش گردابی یکدست و بدون حباب فوم دهید." },
      { t: 7, s: "مرحله ۳ (۷-۱۰s): در دمای ۶۲ درجه شیرینی طبیعی لاکتوز به حداکثر می‌رسد." },
      { t: 10, s: "مرحله ۴ (۱۰-۱۳s): ترکیب مخملی با میکس هارمونی و لاته آرت ماندگار!" }
    ],
    3: [
      { t: 0, s: "مرحله ۱ (۰-۳s): بسکت کورکن را داخل پرتافیلتر محکم قفل کنید." },
      { t: 3, s: "مرحله ۲ (۳-۷s): ۵ بار شات ۵ ثانیه‌ای جهت گردش فشار ۹ بار بویلر." },
      { t: 7, s: "مرحله ۳ (۷-۱۰s): تخلیه روغن‌های سوخته و شستشوی کامل توری دوش." },
      { t: 10, s: "مرحله ۴ (۱۰-۱۳s): تضمین شفافیت طعم شات‌های فردا و محافظت از واشر!" }
    ]
  };

  // Particles for animations
  let particles = [];
  for (let i = 0; i < 40; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 3,
      vy: Math.random() * 2 + 1,
      r: Math.random() * 3 + 1,
      c: videoNum === 1 ? "#ff7836" : videoNum === 2 ? "#ffffff" : "#0ea5e9"
    });
  }

  function renderAnim() {
    const elapsed = Date.now() - startTime;
    const progress = Math.min(1, elapsed / totalDuration);
    const sec = elapsed / 1000;

    if (progEl) progEl.style.width = `${(progress * 100).toFixed(1)}%`;

    // Subtitle update
    const subs = subtitles[videoNum];
    for (let i = subs.length - 1; i >= 0; i--) {
      if (sec >= subs[i].t) {
        if (subEl) subEl.textContent = subs[i].s;
        break;
      }
    }

    // Clear canvas
    ctx.fillStyle = "#121316";
    ctx.fillRect(0, 0, w, h);

    if (videoNum === 1) {
      // ANIMATION 1: GRINDER MORPHOLOGY & PARTICLES
      // Draw Hopper
      ctx.strokeStyle = "#ff5714";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(140, 25);
      ctx.lineTo(220, 25);
      ctx.lineTo(195, 80);
      ctx.lineTo(165, 80);
      ctx.closePath();
      ctx.stroke();

      // Rotating Collar Dial
      ctx.save();
      ctx.translate(180, 100);
      ctx.rotate(progress * Math.PI * 4);
      ctx.fillStyle = "#2c2d33";
      ctx.fillRect(-30, -12, 60, 24);
      ctx.strokeStyle = "#ff7836";
      ctx.strokeRect(-30, -12, 60, 24);
      ctx.fillStyle = "#ff5714";
      ctx.fillRect(-4, -12, 8, 24);
      ctx.restore();

      // Falling coffee particles
      particles.forEach(p => {
        p.y += p.vy * 1.5;
        if (p.y > 180) { p.y = 85; p.x = 175 + (Math.random() - 0.5) * 15; }
        ctx.fillStyle = p.c;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // Portafilter below
      ctx.fillStyle = "#363842";
      ctx.fillRect(150, 155, 60, 25);
      ctx.strokeStyle = "#ff5714";
      ctx.strokeRect(150, 155, 60, 25);
    } else if (videoNum === 2) {
      // ANIMATION 2: STEAMING VORTEX & MILK FOAM
      // Pitcher
      ctx.strokeStyle = "rgba(255, 255, 255, 0.4)";
      ctx.lineWidth = 3;
      ctx.strokeRect(140, 50, 80, 110);

      // Liquid level rising
      const milkHeight = 40 + progress * 45;
      ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
      ctx.fillRect(142, 160 - milkHeight, 76, milkHeight);

      // Steam wand at 45 deg with steam bubbles
      ctx.strokeStyle = "#ff5714";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(110, 30);
      ctx.lineTo(165, 120);
      ctx.stroke();

      // Swirling vortex bubbles
      ctx.save();
      ctx.translate(180, 160 - milkHeight / 2);
      ctx.rotate(elapsed * 0.008);
      for (let i = 0; i < 18; i++) {
        const rad = (i * 2.5);
        const ang = i * 0.8;
        ctx.fillStyle = `rgba(255, 255, 255, ${0.4 + (i / 30)})`;
        ctx.beginPath();
        ctx.arc(Math.cos(ang) * rad, Math.sin(ang) * rad, 3, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Temperature meter
      const curTemp = (55 + progress * 10).toFixed(0);
      ctx.fillStyle = "#ff5714";
      ctx.font = "bold 13px Tahoma";
      ctx.fillText(`🌡️ ${curTemp}°C`, 235, 110);
    } else if (videoNum === 3) {
      // ANIMATION 3: 3-STAGE BACKFLUSH & WATER PRESSURE PULSE
      // Grouphead
      ctx.fillStyle = "#2c2d33";
      ctx.fillRect(125, 30, 110, 35);
      ctx.strokeStyle = "#404450";
      ctx.strokeRect(125, 30, 110, 35);

      // Pressure Gauge
      const pulse = Math.sin(elapsed * 0.01) * 0.5 + 0.5;
      const barPressure = (8.5 + pulse * 0.8).toFixed(1);

      ctx.fillStyle = "#0ea5e9";
      ctx.font = "bold 13px Tahoma";
      ctx.fillText(`⚡ ${barPressure} Bar`, 245, 55);

      // Blind Portafilter
      ctx.fillStyle = "#1e2025";
      ctx.fillRect(145, 70, 70, 45);
      ctx.strokeStyle = "#0ea5e9";
      ctx.lineWidth = 2;
      ctx.strokeRect(145, 70, 70, 45);

      // Water flush pulsing back
      for (let i = 0; i < 20; i++) {
        const py = 100 - (elapsed * 0.1 + i * 8) % 35;
        ctx.fillStyle = `rgba(14, 165, 233, ${Math.random() * 0.6 + 0.2})`;
        ctx.beginPath();
        ctx.arc(155 + (i * 3) % 50, py, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Dirty oil flushing out sides
      if (progress > 0.4) {
        ctx.fillStyle = "rgba(255, 120, 54, 0.6)";
        ctx.fillRect(135, 75, 8, 25);
        ctx.fillRect(217, 75, 8, 25);
      }
    }

    if (progress < 1) {
      academyAnimFrames[videoNum] = requestAnimationFrame(renderAnim);
    } else {
      if (frame) frame.classList.remove("playing");
      if (subEl) subEl.textContent = "✓ پایان آموزش ۱۳ ثانیه‌ای • برای بازپخش انیمیشن کلیک کنید";
    }
  }

  renderAnim();
}

/* ===================================================================
   GUILAN CLIMATE DIAL-IN ASSISTANT (IDEA 1)
   =================================================================== */
const GUILAN_CITY_PRESETS = {
  "rasht": {
    name: "رشت",
    humidity: "رطوبت ۷۸٪ (بارانی و متراکم)",
    adjust: "به دلیل رطوبت بالای رشت، سابه در هوای آزاد رطوبت جذب کرده و عصاره‌گیری کندتر می‌شود. درجه آسیاب را <b>۰.۳ تا ۰.۵ درجه درشت‌تر (Coarser)</b> بگیرید و وزن سابه در بسکت را روی <b>۱۸.۰ گرم دقیق</b> قفل کنید.",
    temp: "دمای بویلر: ۹۲.۰°C • زمان شات: ۲۶ ثانیه"
  },
  "anzali": {
    name: "بندر انزلی",
    humidity: "رطوبت ۹۰٪ (شرجی ساحلی شدید)",
    adjust: "در هوای فوق‌العاده شرجی انزلی، دانه در هاپر متورم می‌شود. درجه آسیاب را <b>۰.۵ تا ۰.۸ درجه درشت‌تر</b> کنید و هاپر را پر نکنید؛ هر ۲۰ شات دانه تازه از پاکت سوپاپ‌دار شارژ کنید.",
    temp: "دمای بویلر: ۹۱.۵°C • زمان شات: ۲۵ ثانیه"
  },
  "lahijan": {
    name: "لاهیجان",
    humidity: "رطوبت ۶۵٪ (کوهپایه‌ای معتدل)",
    adjust: "شرایط ایده‌آل برای ثبات عصاره‌گیری. کالیبراسیون استاندارد را حفظ کنید؛ درجه آسیاب معمولی با تمپینگ یکدست ۲۰ کیلوگرمی برای استخراج کامل نت‌های گلی و کاراملی.",
    temp: "دمای بویلر: ۹۲.۸°C • زمان شات: ۲۷ ثانیه"
  },
  "fouman": {
    name: "فومن / صومعه‌سرا",
    humidity: "رطوبت ۷۵٪ (جلگه‌ای مرطوب)",
    adjust: "درجه آسیاب را <b>۰.۳ درجه درشت‌تر</b> بگیرید. از ابزار WDT سوزنی قبل از تمپ استفاده کنید تا رطوبت محیطی باعث چنلینگ در دیواره بسکت نشود.",
    temp: "دمای بویلر: ۹۲.۰°C • زمان شات: ۲۶ ثانیه"
  },
  "rudsar": {
    name: "رودسر / لنگرود / چابکسر",
    humidity: "رطوبت ۸۵٪ (ساحلی شرجی)",
    adjust: "درجه آسیاب <b>۰.۴ درجه درشت‌تر</b>. قبل از هر شات پورتافیلتر را کاملاً با دستمال میکروفایبر خشک کنید تا رطوبت مانده روی توری عصاره را ترش نکند.",
    temp: "دمای بویلر: ۹۱.۵°C • زمان شات: ۲۵ ثانیه"
  },
  "talesh": {
    name: "تالش / آستارا",
    humidity: "رطوبت ۷۰٪ (کوهستان و ساحل)",
    adjust: "نوسان دمای شب و روز بالاست. در شیفت صبح درجه آسیاب را <b>۰.۲ درجه ریزتر</b> و در شیفت عصر با بالا رفتن رطوبت <b>۰.۳ درشت‌تر</b> تنظیم کنید.",
    temp: "دمای بویلر: ۹۲.۵°C • زمان شات: ۲۷ ثانیه"
  }
};

function calculateGuilanDialIn() {
  const cityKey = $("#wCity")?.value || "rasht";
  const grinder = $("#wGrinder")?.value || "home025";
  const bean = $("#wBean")?.value || "aflatoun";
  const conf = GUILAN_CITY_PRESETS[cityKey];
  const box = $("#weatherResultBox");
  if (!conf || !box) return;

  $("#wResCity").textContent = conf.name;
  $("#wResTitle").textContent = `کالیبراسیون تخصصی ${conf.name} • ${conf.humidity}`;
  $("#wResText").innerHTML = `
    <p style="margin:0 0 6px;">${conf.adjust}</p>
    <div style="background:var(--brass-light);border:1px dashed var(--brass);padding:8px 12px;border-radius:8px;font-weight:800;color:var(--brass);font-size:13px;">
      🎯 تنظیم بهینه دستگاه: ${conf.temp}
    </div>
  `;
  box.style.display = "grid";
}

/* ===================================================================
   CAFE ORDER CART & STORAGE ENGINE (AUTO-SAVING DESK)
   =================================================================== */
let cafeCart = {};

function loadCafeCart() {
  try {
    const saved = localStorage.getItem("siloCafeCart");
    if (saved) cafeCart = JSON.parse(saved);
    Object.values(cafeCart).forEach((it) => {
      if (!it.unit) it.unit = cartItemUnit(it.id);
    });
  } catch(e){}
  renderCafeCart();
  restoreCafeMeta();
}

function restoreCafeMeta() {
  try {
    const meta = JSON.parse(localStorage.getItem("siloCafeMeta") || "{}");
    if (meta.name && $("#cartCafeName")) $("#cartCafeName").value = meta.name;
    if (meta.phone && $("#cartCafePhone")) $("#cartCafePhone").value = meta.phone;
  } catch(e){}
  renderBirthdayBanner();
}

function saveCafeMeta() {
  try {
    localStorage.setItem("siloCafeMeta", JSON.stringify({
      name: $("#cartCafeName")?.value || "",
      phone: $("#cartCafePhone")?.value || "",
    }));
  } catch(e){}
  renderBirthdayBanner();
}

function bindCartMeta() {
  ["cartCafeName", "cartCafePhone"].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("change", saveCafeMeta);
    el.addEventListener("input", saveCafeMeta);
  });
}

function saveCafeCart() {
  try {
    localStorage.setItem("siloCafeCart", JSON.stringify(cafeCart));
  } catch(e){}
  renderCafeCart();
}

function cartItemUnit(id) {
  const item = byId(id);
  return item?.unit || "کیلو";
}

function syncCartDeskFromUser() {
  const user = window.siloPortalUser;
  const sub = $("#cartHeadSub");
  const title = $("#cartDrawer")?.querySelector(".cart-head h3");
  const fields = $("#cartCafeFields");
  const chip = $("#cartUserChip");
  const nameEl = $("#cartCafeName");
  const phoneEl = $("#cartCafePhone");

  if (user) {
    if (nameEl && user.display_name) nameEl.value = user.display_name;
    if (phoneEl && user.phone) phoneEl.value = "0" + String(user.phone).slice(2);
    if (fields) fields.hidden = true;
    if (chip) {
      chip.hidden = false;
      chip.innerHTML = `<strong>${user.display_name || "کافه شما"}</strong><span dir="ltr">${user.phone_masked || ""}</span>`;
    }
    saveCafeMeta();
    if (title) title.textContent = "سبد کافه روز";
    if (sub) sub.textContent = "ارسال فاکتور به شهاب قریشی (واتساپ)";
  } else {
    if (fields) fields.hidden = false;
    if (chip) chip.hidden = true;
    if (title) title.textContent = "سبد سفارش";
    if (sub) sub.textContent = "افزودن از کاتالوگ · ارسال در واتساپ";
  }
}

function addToCartItem(id, name, type) {
  const unit = cartItemUnit(id);
  if (!cafeCart[id]) {
    cafeCart[id] = { id, name, type, unit, qty: 1 };
  } else {
    cafeCart[id].qty += 1;
  }
  syncCartDeskFromUser();
  saveCafeCart();
  openCartDrawer();
}

function updateCartQty(id, delta) {
  if (!cafeCart[id]) return;
  cafeCart[id].qty += delta;
  if (cafeCart[id].qty <= 0) {
    delete cafeCart[id];
  }
  saveCafeCart();
}

function removeCartItem(id) {
  delete cafeCart[id];
  saveCafeCart();
}

function renderCafeCart() {
  const items = Object.values(cafeCart);
  const lineCount = items.length;
  const totalKg = items.reduce((acc, it) => {
    const u = it.unit || cartItemUnit(it.id);
    if (u === "کیلو") return acc + it.qty;
    return acc + it.qty;
  }, 0);

  const badge = $("#cartBadgeCount");
  if (badge) badge.textContent = faNum(lineCount);

  const mobBadge = $("#mobCartBadge");
  if (mobBadge) mobBadge.textContent = faNum(lineCount);

  syncCartDeskFromUser();

  const totalEl = $("#cartItemsTotal");
  if (totalEl) {
    if (lineCount === 0) totalEl.textContent = "۰ قلم";
    else if (totalKg > 0 && items.every((it) => (it.unit || cartItemUnit(it.id)) === "کیلو")) {
      totalEl.textContent = `${faNum(lineCount)} قلم · ${faNum(totalKg)} کیلو`;
    } else {
      totalEl.textContent = `${faNum(lineCount)} قلم`;
    }
  }

  const list = $("#cartItemsList");
  if (!list) return;

  if (items.length === 0) {
    list.innerHTML = `
      <div class="cart-empty-msg">
        <p class="cart-empty-title">سبد خالی است</p>
        <p class="cart-empty-hint">روی «افزودن به سبد» در کاتالوگ بزنید.</p>
      </div>
    `;
    return;
  }

  list.innerHTML = items.map(it => {
    const unit = it.unit || cartItemUnit(it.id);
    const qtyLabel = unit === "کیلو" ? "کیلو" : unit;
    return `
    <div class="cart-line-item">
      <div class="cart-line-info">
        <div class="cart-line-title">${it.name}</div>
        <div class="cart-line-type">${it.type}</div>
      </div>
      <div class="cart-qty-ctrl" title="هر واحد = یک ${qtyLabel}">
        <button class="cart-qty-btn" onclick="updateCartQty('${it.id}', -1)" type="button" aria-label="کم کردن">−</button>
        <span class="cart-qty-num">${faNum(it.qty)} <small>${qtyLabel}</small></span>
        <button class="cart-qty-btn" onclick="updateCartQty('${it.id}', 1)" type="button" aria-label="زیاد کردن">+</button>
      </div>
      <button class="cart-remove-btn" onclick="removeCartItem('${it.id}')" title="حذف" type="button">✕</button>
    </div>
  `;
  }).join("");
}

function openCartDrawer() {
  syncCartDeskFromUser();
  $("#cartDrawer")?.classList.add("open");
  $("#cartOverlay")?.classList.add("open");
}

function closeCartDrawer() {
  $("#cartDrawer")?.classList.remove("open");
  $("#cartOverlay")?.classList.remove("open");
}

function buildCartWhatsAppMessage(recipientName) {
  const items = Object.values(cafeCart);
  if (items.length === 0) return null;
  const portal = window.siloPortalUser;
  const cafeName =
    portal?.display_name ||
    $("#cartCafeName")?.value.trim() ||
    "همکار گرامی";
  const cafePhone =
    (portal?.phone ? "0" + String(portal.phone).slice(2) : "") ||
    $("#cartCafePhone")?.value.trim();
  const wantsCallback = $("#cartMorningCallback")?.checked;
  const dateStr = new Date().toLocaleDateString("fa-IR");
  
  let lines = items.map((it, idx) => {
    const unit = it.unit || cartItemUnit(it.id);
    const q = unit === "کیلو" ? `${faNum(it.qty)} کیلو` : `${faNum(it.qty)} ${unit}`;
    return `${idx + 1}. ${it.name} (${it.type}) — ${q}`;
  }).join("\n");
  let extra = "";
  if (cafePhone) extra += `\n📞 موبایل کافه: ${cafePhone}`;
  if (wantsCallback) extra += `\n⏰ درخواست تماس: فردا ساعت ۱۰ تا ۱۲ صبح کارشناس فروش با این کافه تماس بگیرد.`;
  
  return `سلام ${recipientName} عزیز،
سفارش ثبت‌شده از کاتالوگ آنلاین سیلو (silosepher.ir)

📍 کافه: ${cafeName}${extra}
📅 تاریخ ثبت: ${dateStr}

📋 لیست اقلام درخواستی:
${lines}

لطفاً جهت تأیید موجودی، هماهنگی قیمت روز و زمان ارسال با ما هماهنگ کنید. ممنون از شما!`;
}

function checkoutToSales() {
  const msg = buildCartWhatsAppMessage("شهاب قریشی (مدیریت فروش سیلو)");
  if (!msg) {
    alert("سبد سفارش شما خالی است؛ لطفاً ابتدا اقلام موردنظر را انتخاب کنید.");
    return;
  }
  window.open(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`, "_blank");
}

function checkoutToService() {
  const msg = buildCartWhatsAppMessage("مهندس پوراحمدی (خدمات و قطعات سیلو)");
  if (!msg) {
    alert("سبد سفارش شما خالی است؛ لطفاً ابتدا اقلام موردنظر را انتخاب کنید.");
    return;
  }
  window.open(`https://wa.me/${SERVICE_WA}?text=${encodeURIComponent(msg)}`, "_blank");
}

/* ===================================================================
   BARISTA MODE, WEATHER ORDER, SOS, BIRTHDAY, BENCHMARK, PWA
   =================================================================== */
function toggleBaristaMode() {
  const on = document.documentElement.classList.toggle("barista-mode");
  $("#baristaModeBtn")?.classList.toggle("on", on);
  try { localStorage.setItem("siloBaristaMode", on ? "1" : "0"); } catch(e){}
}

function restoreBaristaMode() {
  try {
    if (localStorage.getItem("siloBaristaMode") === "1") {
      document.documentElement.classList.add("barista-mode");
      $("#baristaModeBtn")?.classList.add("on");
    }
  } catch(e){}
}

const WX_CITIES = {
  rasht: { name: "رشت", lat: 37.2808, lon: 49.5832 },
  lahijan: { name: "لاهیجان", lat: 37.2073, lon: 50.0039 },
  anzali: { name: "انزلی", lat: 37.4726, lon: 49.4622 },
  fouman: { name: "فومن", lat: 37.2239, lon: 49.3125 },
  langarud: { name: "لنگرود", lat: 37.197, lon: 50.1536 }
};
let weatherSuggestion = { id: "aflatoun", name: "میکس افلاطون (۸۰R/۲۰A)", qty: 20 };

async function loadWeatherOrder() {
  const key = $("#wxCity")?.value || "rasht";
  const city = WX_CITIES[key];
  const line = $("#wxLine");
  if (!city || !line) return;
  line.textContent = `در حال خواندن هوای ${city.name}…`;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min&timezone=Asia%2FTehran&forecast_days=2`;
    const res = await fetch(url);
    const data = await res.json();
    const now = data.current?.temperature_2m;
    const hum = data.current?.relative_humidity_2m;
    const t0 = data.daily?.temperature_2m_max?.[0];
    const t1 = data.daily?.temperature_2m_max?.[1];
    const drop = (typeof t0 === "number" && typeof t1 === "number") ? Math.round(t0 - t1) : 0;
    applyWeatherCopy(city.name, now, hum, drop);
  } catch (err) {
    line.textContent = `اتصال هوا برقرار نشد. برای ${city.name} اگر هوا سردتر شد، میکس افلاطون برای نوشیدنی شیری بیرون‌بر را بیشتر بردارید.`;
    weatherSuggestion = { id: "aflatoun", name: "میکس افلاطون (۸۰R/۲۰A)", qty: 20 };
  }
}

function applyWeatherCopy(cityName, now, hum, drop) {
  const line = $("#wxLine");
  const temp = typeof now === "number" ? Math.round(now) : null;
  const humid = typeof hum === "number" ? Math.round(hum) : null;
  let text = "";
  if (temp !== null && temp <= 12) {
    weatherSuggestion = { id: "aflatoun", name: "میکس افلاطون (۸۰R/۲۰A)", qty: 25 };
    text = `هوای ${cityName} حدود ${faNum(temp)} درجه است؛ نوشیدنی شیری و بیرون‌بر بالا می‌رود. پیشنهاد: حدود ۲۰٪ افلاطون بیشتر از هفتهٔ گرم.`;
  } else if (temp !== null && temp >= 26) {
    weatherSuggestion = { id: "ethiopia", name: "عربیکا اتیوپی (یرگاچف)", qty: 10 };
    text = `هوای ${cityName} حدود ${faNum(temp)} درجه و گرم است؛ آیس و دمی بیشتر می‌شود. پیشنهاد: یرگاچف و کلمبیا برای منوی سرد.`;
  } else {
    weatherSuggestion = { id: "harmony", name: "میکس هارمونی (۷۰R/۳۰A)", qty: 20 };
    text = `هوای ${cityName} معتدل است${temp !== null ? " (حدود " + faNum(temp) + " درجه)" : ""}. هارمونی تعادل خوبی برای اسپرسو و شیر می‌دهد.`;
  }
  if (drop >= 4) {
    weatherSuggestion = { id: "aflatoun", name: "میکس افلاطون (۸۰R/۲۰A)", qty: 25 };
    text = `فردا در ${cityName} حدود ${faNum(drop)} درجه سردتر می‌شود؛ احتمالاً تقاضا برای نوشیدنی گرم و درب‌دار بالا می‌رود. افلاطون را جلوتر بردارید.`;
  }
  if (humid !== null && humid >= 80) {
    text += ` رطوبت ${faNum(humid)}٪ است؛ سابه را کمی درشت‌تر کنید.`;
  }
  if (line) line.textContent = text;
}

function applyWeatherSuggestion() {
  addToCartItem(weatherSuggestion.id, weatherSuggestion.name, "دانه");
  if (cafeCart[weatherSuggestion.id]) cafeCart[weatherSuggestion.id].qty = weatherSuggestion.qty;
  saveCafeCart();
  openCartDrawer();
}

function openSosModal() {
  $("#sosModal")?.classList.add("open");
  const cafe = $("#cartCafeName")?.value || "";
  if (cafe && $("#sosCity") && !$("#sosCity").value) $("#sosCity").value = cafe;
}
function closeSosModal(ev) {
  if (ev && ev.target !== $("#sosModal")) return;
  $("#sosModal")?.classList.remove("open");
}

function sendSosRequest() {
  const need = $("#sosNeed")?.value || "کسری شیفت";
  const city = $("#sosCity")?.value.trim() || $("#cartCafeName")?.value.trim() || "شهر نامشخص";
  const note = $("#sosNote")?.value.trim() || "فوری";
  const cafe = $("#cartCafeName")?.value.trim() || "کافه همکار";
  const isTech = /قطعه|دستگاه|واشر/.test(need);
  const to = isTech ? SERVICE_WA : WA;
  const who = isTech ? "مهندس پوراحمدی" : "شهاب قریشی";
  const msg = `🚨 SOS سیلو — درخواست اضطراری شیفت\n\n📍 کافه: ${cafe}\n🏙️ محل: ${city}\n📦 نیاز: ${need}\n📝 توضیح: ${note}\n\nلطفاً در اولویت ارسال سریع قرار دهید.`;
  window.open(`https://wa.me/${to}?text=${encodeURIComponent("سلام " + who + " عزیز،\n" + msg)}`, "_blank");
  closeSosModal(null);
}

function dispatchLudicrousOrder() {
  openSosModal();
}

function renderBirthdayBanner() {
  const bar = $("#birthday-banner");
  if (!bar) return;
  const opened = $("#cartCafeOpened")?.value;
  if (!opened) { bar.hidden = true; bar.classList.remove("show"); return; }
  const d = new Date(opened + "T12:00:00");
  const now = new Date();
  const isDay = d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
  if (!isDay) { bar.hidden = true; bar.classList.remove("show"); return; }
  const cafe = $("#cartCafeName")?.value.trim() || "کافه شما";
  bar.hidden = false;
  bar.classList.add("show");
  bar.innerHTML = `🎉 تولد ${cafe} مبارک. امروز کد همکاری ۱۵٪ فقط برای همین شیفت. <button type="button" onclick="claimBirthday()">دریافت از واتساپ</button>`;
}

function claimBirthday() {
  const cafe = $("#cartCafeName")?.value.trim() || "کافه همکار";
  const msg = `سلام شهاب قریشی عزیز،\nامروز سالگرد کافه ${cafe} است. لطفاً کد همکاری ۱۵٪ امروز را برای سفارش فعال کنید.`;
  window.open(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`, "_blank");
}

function renderCartBenchmark() {
  /* benchmark UI removed — keep stub for older calls */
}

let deferredPwaPrompt = null;
function isStandalonePwa() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
}
function isIosDevice() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}
function syncPwaClass() {
  const bar = $("#pwaInstallBar");
  const on = !!(bar && !bar.hidden && bar.classList.contains("show"));
  document.documentElement.classList.toggle("pwa-bar-on", on);
}
function showPwaCue() {
  if (isStandalonePwa()) return;
  if (localStorage.getItem("siloPwaHide") === "1") return;
  if (window.matchMedia("(min-width: 901px)").matches) return;
  const bar = $("#pwaInstallBar");
  if (bar) { bar.hidden = false; bar.classList.add("show"); }
  syncPwaClass();
}
function setupPwa() {
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("sw.js?v=18").catch(() => {});
  }
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPwaPrompt = e;
    showPwaCue();
  });
  if (isStandalonePwa()) {
    const bar = $("#pwaInstallBar");
    if (bar) { bar.hidden = true; bar.classList.remove("show"); }
    const mob = $("#mobInstallBtn");
    if (mob) mob.hidden = true;
    return;
  }
  if (isIosDevice()) showPwaCue();
}
function openPwaHelp() {
  if (deferredPwaPrompt && !isIosDevice()) {
    installSiloPwa();
    return;
  }
  const box = $("#pwaHelp");
  const text = $("#pwaHelpText");
  const btn = $("#pwaHelpInstall");
  if (!box) return;
  if (isIosDevice()) {
    if (text) text.textContent = "در سافاری دکمهٔ Share (مربع و فلش) را بزنید، بعد Add to Home Screen / افزودن به صفحهٔ اصلی را انتخاب کنید.";
    if (btn) btn.hidden = true;
  } else if (location.protocol === "https:" || location.hostname === "localhost") {
    if (text) text.textContent = "از منوی مرورگر گزینهٔ Install app یا افزودن به صفحهٔ اصلی را بزنید. اگر دکمهٔ نصب ظاهر شد همان را لمس کنید.";
    if (btn) btn.hidden = !deferredPwaPrompt;
  } else {
    if (text) text.textContent = "نصب اپ بعد از بارگذاری روی دامنهٔ https://silosepher.ir از منوی مرورگر یا دکمهٔ نصب در پایین صفحه انجام می‌شود.";
    if (btn) btn.hidden = true;
  }
  box.removeAttribute("hidden");
}
function closePwaHelp() {
  const box = $("#pwaHelp");
  if (box) box.setAttribute("hidden", "");
}
function installSiloPwa() {
  if (deferredPwaPrompt) {
    const promptEvent = deferredPwaPrompt;
    promptEvent.prompt();
    const choice = promptEvent.userChoice;
    const done = () => {
      deferredPwaPrompt = null;
      dismissPwaBar();
      closePwaHelp();
    };
    if (choice && typeof choice.then === "function") choice.finally(done);
    else done();
    return;
  }
  openPwaHelp();
}
function dismissPwaBar() {
  const bar = $("#pwaInstallBar");
  if (bar) { bar.hidden = true; bar.classList.remove("show"); }
  try { localStorage.setItem("siloPwaHide", "1"); } catch(e){}
  syncPwaClass();
  closePwaHelp();
}

/* ===================================================================
   ELON MUSK LUDICROUS DISPATCH
   =================================================================== */
/* ===================================================================
   JEFF BEZOS QUICK RE-ORDER FLYWHEEL
   =================================================================== */
function quickAddReorder(packType) {
  if (packType === 'busy') {
    addToCartItem('aflatoun', 'میکس افلاطون (۸۰R/۲۰A)', 'دانه');
    cafeCart['aflatoun'].qty = 50;
  } else if (packType === 'balance') {
    addToCartItem('harmony', 'میکس هارمونی (۷۰R/۳۰A)', 'دانه');
    cafeCart['harmony'].qty = 30;
    addToCartItem('sumatra', 'میکس سوماترا', 'دانه');
    cafeCart['sumatra'].qty = 10;
  } else if (packType === 'special') {
    addToCartItem('ethiopia', 'عربیکا اتیوپی (یرگاچف)', 'دانه');
    cafeCart['ethiopia'].qty = 10;
    addToCartItem('colombia', 'عربیکا کلمبیا (سوپریمو)', 'دانه');
    cafeCart['colombia'].qty = 10;
  }
  saveCafeCart();
  openCartDrawer();
}

/* ===================================================================
   SAM ALTMAN AI BLEND SOMMELIER (MATCHING EXACT CATALOG PRODUCTS)
   =================================================================== */
let generatedAiBlendData = null;

const AI_RECOMMENDED_PRODUCTS = {
  aflatoun: {
    id: "aflatoun",
    title: "میکس افلاطون (۸۰ روبوستا / ۲۰ عربیکا)",
    matchReason: "بهترین انتخاب برای منوی بر پایه شیر و ذائقه تلخی پرقدرت و کرمای ماندگار.",
    grindDesc: "تنظیم آسیاب هوم یا مازر: درجه سابه ریز و متراکم، ۲۲ الی ۲۵ ثانیه عصاره‌گیری با تمپینگ یکدست.",
    badge: "پرفروش‌ترین ترکیب بارهای شلوغ"
  },
  harmony: {
    id: "harmony",
    title: "میکس هارمونی (۷۰ روبوستا / ۳۰ عربیکا)",
    matchReason: "بالانس بی‌نقص برای تمام منو (شیر و اسپرسو خالص)؛ هارمونی کرما و عطر کاراملی.",
    grindDesc: "تنظیم آسیاب: کالیبراسیون استاندارد ۲۴ تا ۲۶ ثانیه، دمای بویلر ۹۲ درجه جهت استخراج حداکثر شیرینی.",
    badge: "ترکیب استاندارد طلایی سیلو"
  },
  sumatra: {
    id: "sumatra",
    title: "میکس سوماترا (پایه روبوستا اندونزی + پی‌بی + چری + هند)",
    matchReason: "انرژی و کافئین بالا با بادی متراکم؛ میکس است، نه دانهٔ تک‌خاستگاه.",
    grindDesc: "تنظیم آسیاب: سابه متوسط ریز با نسبت ۱۸g به ۳۶g خروجی، فوق‌العاده برای شات‌های پرکافئین.",
    badge: "میکس مدیوم دارک"
  },
  supernova: {
    id: "supernova",
    title: "میکس سوپرنوآ (پایه ویتنام + سه روبوستا + پی‌بی + چری)",
    matchReason: "پرانرژی و اقتصادی برای بار شلوغ؛ پایه ویتنام است و چند روبوستای دیگر هم داخل ترکیب است.",
    grindDesc: "تنظیم آسیاب: ۲۲ تا ۲۴ ثانیه، سریع و پرکرم برای انواع آیس کافی و نوشیدنی‌های بیرون‌بر.",
    badge: "میکس اقتصادی"
  },
  ethiopia: {
    id: "ethiopia",
    title: "عربیکا اتیوپی یرگاچف (تک‌خاستگاه)",
    matchReason: "ایده‌آل برای متدهای دمی دستی (V60، کمکس) و مشتریان علاقه‌مند به عطر گل یاس و اسیدیته میوه‌ای.",
    grindDesc: "تنظیم آسیاب: سابه درشت‌تر (Medium Coarse) با نسبت ۱ به ۱۶ و دمای آب ۹۱ درجه.",
    badge: "اسپشیالتی موج سوم"
  },
  colombia: {
    id: "colombia",
    title: "عربیکا کلمبیا سوپریمو",
    matchReason: "اسپرسوی متعادل با نت شکلات شیری و فندق، بدون تلخی زننده.",
    grindDesc: "آسیاب: ۲۵ تا ۲۷ ثانیه، دمای بویلر حدود ۹۳ درجه.",
    badge: "عربیکا همه‌کاره"
  },
  vitali: {
    id: "vitali",
    title: "میکس ویتالی (۵۰ روبوستا / ۵۰ عربیکا)",
    matchReason: "وقتی منو هم اسپرسو می‌خواهد هم شیر؛ نصف‌نصف، رُست شکلاتی.",
    grindDesc: "آسیاب: ۲۵ تا ۲۷ ثانیه، دمای بویلر ۹۲ درجه.",
    badge: "نام اختصاصی سیلو"
  },
  indo90: {
    id: "indo90",
    title: "میکس اندونزی ۹۰/۱۰",
    matchReason: "بار پرشات و نوشیدنی شیری؛ پایه روبوستا اندونزی، رُست مدیوم‌دارک قهوه‌ای.",
    grindDesc: "آسیاب: ۲۲ تا ۲۵ ثانیه. برای شیر و بیرون‌بر.",
    badge: "پایه روبوستا اندونزی"
  }
};

function generateAiBlend() {
  const drink = $("#aiQDrink")?.value;
  const taste = $("#aiQTaste")?.value;
  const cafeName = $("#aiQCafeName")?.value.trim() || "کافه شما";

  let matchKey = "harmony";

  if (drink === "filter" || taste === "fruity") {
    matchKey = "ethiopia";
  } else if (drink === "milk" && taste === "heavy") {
    matchKey = "aflatoun";
  } else if (drink === "milk" && taste === "balanced") {
    matchKey = "harmony";
  } else if (drink === "espresso" && taste === "heavy") {
    matchKey = "sumatra";
  } else if (drink === "espresso" && taste === "balanced") {
    matchKey = "vitali";
  } else if (drink === "mix" && taste === "balanced") {
    matchKey = "vitali";
  } else if (taste === "heavy") {
    matchKey = "indo90";
  } else {
    matchKey = "harmony";
  }

  const selected = AI_RECOMMENDED_PRODUCTS[matchKey];
  generatedAiBlendData = {
    id: selected.id,
    name: selected.title,
    type: "دانه پیشنهادی هوش مصنوعی",
    desc: selected.matchReason
  };

  $("#aiResultTitle").textContent = `✨ پیشنهاد هوشمند سیلو برای ${cafeName}: ${selected.title}`;
  $("#aiResultDesc").innerHTML = `
    <div style="background:#fff;border:1px solid var(--line-strong);border-radius:10px;padding:12px;margin-bottom:10px">
      <span style="display:inline-block;background:var(--brass-light);color:var(--brass);font-size:11px;font-weight:800;padding:2px 8px;border-radius:6px;margin-bottom:6px">📌 ${selected.badge}</span>
      <p style="margin:0 0 6px;font-weight:800;color:var(--paper)"><b>علت انتخاب:</b> ${selected.matchReason}</p>
      <p style="margin:0;font-size:13px;color:var(--paper-dim)"><b>توصیه باریستا و آسیاب:</b> ${selected.grindDesc}</p>
    </div>
  `;
  
  const waMsg = `سلام شهاب قریشی عزیز،\nبر اساس دستیار هوش مصنوعی سیلو برای ${cafeName}:\n\n📋 محصول پیشنهادی: ${selected.title}\n🎯 کاربرد در بار: ${selected.matchReason}\n⚙️ توصیه کالیبراسیون: ${selected.grindDesc}\n\nلطفاً جهت ثبت سفارش یا ارسال نمونه برای کافه‌مون هماهنگ بفرمایید.`;
  $("#aiBtnWa").href = `https://wa.me/${WA}?text=${encodeURIComponent(waMsg)}`;
  $("#aiOutputBox").style.display = "block";
}

function addAiBlendToCart() {
  if (!generatedAiBlendData) return;
  addToCartItem(generatedAiBlendData.id, generatedAiBlendData.name, "دانه پیشنهادی هوش مصنوعی");
}

/* ===================================================================
   SERVICE BOOKING (IDEA 2)
   =================================================================== */
function submitServiceBooking() {
  const cafe = $("#srvCafe")?.value.trim() || "نامشخص";
  const machine = $("#srvMachine")?.value.trim() || "نامشخص";
  const type = $("#srvType")?.value || "سرویس دوره‌ای";
  const msg = `سلام مهندس پوراحمدی عزیز،\nدرخواست ثبت نوبت خدمت از سایت سیلو:\nکافه و شهر: ${cafe}\nدستگاه/آسیاب: ${machine}\nنوع خدمت: ${type}\nلطفاً برای هماهنگی زمان بازدید راهنمایی بفرمایید.`;
  window.open(`https://wa.me/${SERVICE_WA}?text=${encodeURIComponent(msg)}`, "_blank");
}

function bindEntryGate() {
  const gate = $("#siloEntryGate");
  const btn = $("#siloGateEnter");
  if (!gate || !btn) return;
  btn.onclick = () => {
    gate.hidden = true;
    document.body.classList.remove("silo-gated");
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  };
}

/* ===================================================================
   INIT
   =================================================================== */
bindEntryGate();
$("#wa")?.setAttribute("href", `https://wa.me/${WA}`);

if (location.protocol === "file:" || new URLSearchParams(location.search).has("preview")) {
  const bar = $("#preview-banner");
  if (bar) {
    bar.hidden = false;
    bar.classList.add("show");
  }
}

catalog = { items: typeof FALLBACK_ITEMS !== "undefined" ? FALLBACK_ITEMS : [], updated_at: "", source: "demo", catalog_only: Boolean(window.SILO_CATALOG_ONLY) };
if (catalog.items.length) renderBoard();
function initCatalogCards() {
  bindFlavorRadars();
  compactCatalogCards();
  bindPassportButtons();
}

(async function bootPublicSite() {
  await loadSiteMode();
  await loadPrices();
  if (!siteMode.catalog_only) {
    loadCafeLayer();
    setInterval(loadPrices, 60 * 60 * 1000);
  }
  if (catalog.items.length) renderBoard();
  initCatalogCards();
})();
bindMix();
bindFloors();
initCatalogCards();
bindRecommender();
bindProfitCalculator();
bindDoctor();
bindSpotlight();
loadCafeCart();
bindCartMeta();
initAcademyCanvases();
restoreBaristaMode();
loadWeatherOrder();
setupPwa();
