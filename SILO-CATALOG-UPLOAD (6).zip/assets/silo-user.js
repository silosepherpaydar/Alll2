/* پنل کاربری ساده — موبایل + رمز (ثبت‌نام / ورود). سمت سرور در صورت PHP؛ وگرنه localStorage. */
const SILO_USER_LS = "silo_portal_accounts_v1";
const SILO_USER_SESSION_LS = "silo_portal_session_v1";

function normalizePhoneFa(raw) {
  const fa = "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩";
  const en = "01234567890123456789";
  let s = String(raw || "").trim();
  for (let i = 0; i < fa.length; i++) s = s.split(fa[i]).join(en[i]);
  s = s.replace(/\D/g, "");
  if (s.startsWith("98")) s = s.slice(2);
  if (s.startsWith("0")) s = s.slice(1);
  if (s.length === 10 && s[0] === "9") return "98" + s;
  return null;
}

function maskPhoneE164(e164) {
  const local = "0" + String(e164).slice(2);
  if (local.length < 11) return "۰۹***";
  return local.slice(0, 4) + "***" + local.slice(-4);
}

async function sha256Hex(text) {
  const buf = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function loadLocalAccounts() {
  try {
    return JSON.parse(localStorage.getItem(SILO_USER_LS) || "{}") || {};
  } catch {
    return {};
  }
}

function saveLocalAccounts(map) {
  localStorage.setItem(SILO_USER_LS, JSON.stringify(map));
}

function readLocalSession() {
  try {
    return JSON.parse(localStorage.getItem(SILO_USER_SESSION_LS) || "null");
  } catch {
    return null;
  }
}

function writeLocalSession(user) {
  if (user) localStorage.setItem(SILO_USER_SESSION_LS, JSON.stringify(user));
  else localStorage.removeItem(SILO_USER_SESSION_LS);
}

let siloPortalUser = null;
window.siloPortalUser = null;

function renderUserNavBtn() {
  const btn = $("#userPanelBtn");
  if (!btn) return;
  if (siloPortalUser) {
    btn.textContent = siloPortalUser.display_name || "حساب من";
    btn.classList.add("on");
  } else {
    btn.textContent = "پنل کاربری";
    btn.classList.remove("on");
  }
}

function openUserPanel(mode) {
  const panel = $("#userPanel");
  const overlay = $("#userPanelOverlay");
  if (!panel || !overlay) return;
  panel.classList.add("open");
  overlay.classList.add("open");
  showUserPanelView(mode || (siloPortalUser ? "home" : "login"));
}

function closeUserPanel() {
  $("#userPanel")?.classList.remove("open");
  $("#userPanelOverlay")?.classList.remove("open");
}

function showUserPanelView(view) {
  $$("[data-user-view]").forEach((el) => {
    el.hidden = el.dataset.userView !== view;
  });
  const msg = $("#userPanelMsg");
  if (msg) msg.textContent = "";
}

function setUserPanelMsg(text, isErr) {
  const msg = $("#userPanelMsg");
  if (!msg) return;
  msg.textContent = text || "";
  msg.classList.toggle("err", Boolean(isErr));
}

function applyLoggedInUser(user) {
  siloPortalUser = user;
  window.siloPortalUser = user;
  renderUserNavBtn();
  const nameEl = $("#userPanelName");
  const phoneEl = $("#userPanelPhone");
  if (nameEl) nameEl.textContent = user.display_name || "کاربر سیلو";
  if (phoneEl) phoneEl.textContent = user.phone_masked || maskPhoneE164(user.phone);
  const cartPhone = $("#cartCafePhone");
  if (cartPhone && user.phone) cartPhone.value = "0" + user.phone.slice(2);
  const nameInput = $("#cartCafeName");
  if (nameInput && user.display_name) nameInput.value = user.display_name;
  if (typeof syncCartDeskFromUser === "function") syncCartDeskFromUser();
  if (typeof saveCafeMeta === "function") saveCafeMeta();
}

async function portalFetchMe() {
  if (location.protocol === "file:") {
    const local = readLocalSession();
    if (local) applyLoggedInUser(local);
    return;
  }
  try {
    const res = await fetch("api/user/me.php", { credentials: "same-origin", cache: "no-store" });
    if (!res.ok) throw new Error("me");
    const data = await res.json();
    if (data.user) {
      applyLoggedInUser(data.user);
      writeLocalSession(data.user);
      return;
    }
  } catch {
    /* fallback */
  }
  const local = readLocalSession();
  if (local) applyLoggedInUser(local);
}

async function portalRegister() {
  const phone = normalizePhoneFa($("#userRegPhone")?.value);
  const pass = $("#userRegPass")?.value || "";
  const pass2 = $("#userRegPass2")?.value || "";
  const name = ($("#userRegName")?.value || "").trim() || "کاربر سیلو";
  if (!phone) return setUserPanelMsg("شماره موبایل معتبر نیست.", true);
  if (pass.length < 6) return setUserPanelMsg("رمز حداقل ۶ کاراکتر.", true);
  if (pass !== pass2) return setUserPanelMsg("تکرار رمز یکسان نیست.", true);

  if (location.protocol !== "file:") {
    try {
      const res = await fetch("api/user/register.php", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: "0" + phone.slice(2), password: pass, display_name: name }),
      });
      const data = await res.json();
      if (data.ok && data.user) {
        applyLoggedInUser(data.user);
        writeLocalSession(data.user);
        setUserPanelMsg("ثبت‌نام شد. خوش آمدید.");
        showUserPanelView("home");
        return;
      }
      if (data.error) return setUserPanelMsg(data.error, true);
    } catch {
      /* local fallback */
    }
  }

  const accounts = loadLocalAccounts();
  if (accounts[phone]) return setUserPanelMsg("این شماره قبلاً ثبت شده. وارد شوید.", true);
  const hash = await sha256Hex("silo-portal|" + phone + "|" + pass);
  accounts[phone] = { display_name: name, password_hash: hash, created_at: Date.now() };
  saveLocalAccounts(accounts);
  const user = { phone, phone_masked: maskPhoneE164(phone), display_name: name };
  applyLoggedInUser(user);
  writeLocalSession(user);
  setUserPanelMsg("حساب روی این مرورگر ساخته شد.");
  showUserPanelView("home");
}

async function portalLogin() {
  const phone = normalizePhoneFa($("#userLoginPhone")?.value);
  const pass = $("#userLoginPass")?.value || "";
  if (!phone) return setUserPanelMsg("شماره موبایل معتبر نیست.", true);
  if (!pass) return setUserPanelMsg("رمز را وارد کنید.", true);

  if (location.protocol !== "file:") {
    try {
      const res = await fetch("api/user/login.php", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: "0" + phone.slice(2), password: pass }),
      });
      const data = await res.json();
      if (data.ok && data.user) {
        applyLoggedInUser(data.user);
        writeLocalSession(data.user);
        showUserPanelView("home");
        return;
      }
      if (data.error) return setUserPanelMsg(data.error, true);
    } catch {
      /* local */
    }
  }

  const accounts = loadLocalAccounts();
  const row = accounts[phone];
  if (!row) return setUserPanelMsg("حسابی با این شماره نیست. ثبت‌نام کنید.", true);
  const hash = await sha256Hex("silo-portal|" + phone + "|" + pass);
  if (row.password_hash !== hash) return setUserPanelMsg("رمز اشتباه است.", true);
  const user = { phone, phone_masked: maskPhoneE164(phone), display_name: row.display_name || "کاربر سیلو" };
  applyLoggedInUser(user);
  writeLocalSession(user);
  showUserPanelView("home");
}

async function portalLogout() {
  if (location.protocol !== "file:") {
    try {
      await fetch("api/user/logout.php", { method: "POST", credentials: "same-origin" });
    } catch {
      /* ignore */
    }
  }
  siloPortalUser = null;
  window.siloPortalUser = null;
  writeLocalSession(null);
  renderUserNavBtn();
  if (typeof syncCartDeskFromUser === "function") syncCartDeskFromUser();
  showUserPanelView("login");
  setUserPanelMsg("خارج شدید.");
}

function bindUserPanel() {
  $("#userPanelBtn")?.addEventListener("click", () => openUserPanel());
  $("#userPanelOverlay")?.addEventListener("click", closeUserPanel);
  $("#userPanelClose")?.addEventListener("click", closeUserPanel);
  $("#userShowRegister")?.addEventListener("click", (e) => {
    e.preventDefault();
    showUserPanelView("register");
  });
  $("#userShowLogin")?.addEventListener("click", (e) => {
    e.preventDefault();
    showUserPanelView("login");
  });
  $("#userDoRegister")?.addEventListener("click", () => portalRegister());
  $("#userDoLogin")?.addEventListener("click", () => portalLogin());
  $("#userDoLogout")?.addEventListener("click", () => portalLogout());
  portalFetchMe();
}

bindUserPanel();
